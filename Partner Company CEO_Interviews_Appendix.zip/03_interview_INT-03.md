# Interview 3 — System discipline, service accuracy, and the German comparison

**Project:** WorkLedger — China Spring interview series
**Interview code:** INT-03
**Recording date:** 29 April 2026 (file dated 30 April 2026)
**Duration:** approx. 12 minutes
**Participants:** R1 (chairman and general manager), R2 (interviewer), R3 (a second participant)
**Language:** Mandarin. This is an edited English translation.
**Transcription:** machine-generated and lightly corrected. `[unclear]` marks passages whose meaning could not be recovered; `[note]` marks editorial reconstruction.
**Anonymisation:** the company is referred to as China Spring; individuals appear as R1–R3.

## Summary

A short, largely anecdotal interview. R1 argues that managers come in generations—product-focused, strategy-focused, and planning-focused—and that the middle layer is difficult to replace because a boss cannot credibly replace himself. He then develops two linked claims: that Chinese managers routinely mistake the platform for their own capability, and that German precision comes from systems rather than from individual virtue. Three travel episodes carry the argument: a German conductor who rerouted four passengers at no cost, a small-station ticket office that solved a problem the main line could not, and a recent Chinese rail experience that R3 describes as unexpectedly good. The interview breaks off mid-conversation as the group moves to another location.

## Transcript

### 1. Three generations of managers (00:00–01:18)

**R1 (00:00)** — There are generations of managers. The second generation were good with the product; an average bonus does not mean you were the most capable. The third generation are good at strategy—the planners, the people who design and manage. Ideally you get a perfectionist who can both fight and manage. That combination is rare.

**R1 (00:24)** — And sometimes the boss has no choice. Even a very capable boss can only read so much of the data himself. I am one of the old guard, and I know the younger ones should take over. But the middle layer is used to fighting in a particular way, and when the boss hands over a business of a thousand square metres, he says: I cannot replace myself, and I look around and see nobody who can replace me. So the middle layer stays. Their cost of a wrong decision looks low to them—[note] meaning the decision is not theirs to bear. But the system is what it is. If the road the boss pointed to is wrong, either the people below are wrong or the people outside are wrong.

**R1 (01:18)** — And this is also how risk propagates. In Germany and Japan, and even in a city like Shanghai, you see the same thing: these things are about quality. The Chinese mistake belongs to a different category—**we mistake the platform for our own capability**. I feel superior because I am in Shanghai; that superiority has to be earned. The Germans are simply like this. When I visited Germany—Alibaba Cloud came to see me in 2000 and I thought it was extraordinary, a perfect socialist system—their workshops ten years ago already represented three years of lead. They drink beer while they work, and it still lands.

**R2 (02:15)** — Probably.

**R1 (02:16)** — They work like that: close together, music on, beer in hand, and it still comes out right.

**R2 (02:27)** — [unclear] the Chinese understanding of it was different, because—

**R1 (02:31)** — When we first went, everything was immediate. We kept looking, we kept giving feedback, and they answered everything. The people in Hong Kong at that time were extremely hard-working and extremely good to us. We stayed in the German Volkswagen guesthouse because we were inside their system; it was cheap, and the breakfast was so generous that I never ate that well anywhere afterwards. At weekends, when we wanted to go out, they knew the hotel restaurant would not open, so they prepared sandwiches in advance and packed them for us—five people, five packs. I was moved by that. Then we got on the train and left.

### 2. Precision as a property of the system (03:35–04:35)

**R1 (03:35)** — In 2000 [unclear] we already knew they were precise. The flexibility of our own departures was within an hour, sometimes an hour and a half. In Germany we knew the train was exact.

**R1 (04:06)** — An example. Our train was at 2:05, and they run every six minutes. We thought we were fine. We had bought first-class tickets—[note] the seats were a different order of magnitude from what we were used to. We sat down, and then it turned out the carriage was wrong.

**R1 (04:35)** — The conductor told us the train split in two directions. "You have to get off; this part goes one way, that part goes another. Where are you going?" We said the first stop with no other city—[note] meaning our destination was beyond the split. He said: this train does not stop there; that train stops there.

**R1 (05:06)** — We had already booked the hotel. In 2000 I had not been working long, and a loss was a loss. So he said, "I will ask the conductor" [note: the train manager, not the conductor]. And he did.

**R2 (05:34)** — Arranged something specially for you.

**R1 (05:37)** — [unclear: four of us, four different cases] The Germans put us up, the Chinese [unclear]—I could not follow the arrangement. In the end he simply took charge of it. Only later did I understand how unusual that was. At the time, all of us Chinese thought the same way: get me off this train first, sort the rest out later.

**R2 (06:04)** — I do not think that would happen in Germany now.

**R1 (06:07)** — [unclear] We four were the exception rather than the rule. The conductor's expression when he dealt with us was one of real thanks—[note] as though we had done him a favour by letting him help. If he had not rerouted us, [unclear] the switch would have been thrown and we would have been stranded. So you let other people help you. That is why I remember it. And later, perhaps, it stopped happening—because we four never thanked them properly, and people stop doing a thing that nobody acknowledges.

**R1 (06:49)** — We got off at a small station with almost nobody there, and eventually found one person in a little room. We explained the problem. They listed it out. Their system and ours were different; [unclear: they kept saying "Linda told you"—possibly a name in the booking record]. We had paid close to 15 percent more, and there was a problem with the ticket, so we went to fix it. They said the office here never handles this. But there was a machine—[unclear: "CIV"]—inside the [unclear], where you could buy tickets, so we bought them. Even now, I am not sure the high-speed rail has that function.

### 3. A recent counter-example (07:48–09:51)

**R3 (07:48)** — I had the opposite experience last week. I had changed my ticket, then got on the wrong train and could not board. I thought I was finished—I was already short of time. Then someone in the group chat said: come and talk to me, there is no problem. I was still repeating the departure time, and someone outside met me. It turned out to be one-to-one service. They handed me to the person at the transfer station, that person handed me to the platform staff, because you have to exit first and then go up again. And they told me: your train is at such and such a time, at such and such a gate; there is nobody there now, I have something to do, so at that time go to that place and find that person.

**R2 (08:41)** — And he tells you again. China—yes. It really works now. The service is genuinely better than it used to be. I feel the same.

**R1 (08:50)** — That business [unclear].

**R2 (08:52)** — China has caught up in a lot of ways.

**R3 (08:54)** — I was astonished. And it was because I still had no seat.

**R1 (09:02)** — He told me—

**R3 (09:02)** — You can only take one [unclear]. I said, then I will—we had asked whether it was free, because for this leg I had [unclear], and he said it was entirely free. I said it was fine, I would think about it, and I showed him [unclear]. In the end, never mind: there was nobody with me, so just sit together.

**R1 (09:30)** — Otherwise I would have been very curious [unclear].

**R3 (09:34)** — I had to coordinate. And coordination is genuinely hard.

**R1 (09:37)** — It is. But what I took from it was a feeling. I was moved then; I am more moved now, because you were going home on your own. I assumed we could not do this, and they are doing it.

**R2 (09:51)** — We really are moving fast now. Even hotels: if you are going to write a Ctrip review, then whatever small thing you raise, they will give you an excessive amount of service so that you do not write a bad review.

### 4. Break in the conversation (10:04–10:10)

**R1 (10:04)** — And then there is the question of which group of people. Let me talk about that first.

**R3 (10:08)** — One question—

**R1 (10:10)** — For example, in my case, I am only controlling these two [unclear: possibly product lines]. Our deputy director is not enough [unclear], their needs are many, and the trading volume [unclear: "candy", "geography"]. [unclear] This sister handles candy and other things; the younger one is the default; then these two, and others as well. He knows [unclear] will never make new clothes again, and our project is behind this. So this group of people is not—let me give you an example. In Shanghai we had a middle-aged attendant, or 8049 [unclear]. "Sorry, we are closing now."

*[The recording ends here. The group appears to have moved to another location.]*

## Notes for analysis

- The **platform-versus-capability** passage (01:18) is the interview's most quotable claim and connects directly to the attribution problem: what looks like individual competence may be a positional advantage.
- The rail episodes are used as evidence for a **systemic** account of service quality: the German outcome came from a procedure the conductor was authorised to use, not from his character.
- R1's remark at 06:07 — that people stop helping when help goes unacknowledged — is an observation about **unrecorded reciprocity**, and is relevant to what a work ledger can and cannot capture.
