# Interview 4 — Name, losses, and what became controllable

**Project:** WorkLedger — China Spring interview series
**Interview code:** INT-04
**Recording date:** 29 April 2026 (file dated 30 April 2026)
**Duration:** approx. 8 minutes
**Participants:** R1 (chairman and general manager), R2 (interviewer), R3 (a second participant)
**Language:** Mandarin. This is an edited English translation.
**Transcription:** machine-generated and lightly corrected. `[unclear]` marks passages whose meaning could not be recovered; `[note]` marks editorial reconstruction.
**Anonymisation:** the company is referred to as China Spring; individuals appear as R1–R3.

## Summary

A short exchange about identity and survival. R1 explains what the word "China" in the company's name obliges: Shanghai is what makes the claim credible, and the spring itself is only his habit. He then describes the loss-making years that put him in the general manager's chair, and attributes the losses to a cohort that mistook a social dividend for its own role. The turning point was shutting down one company and turning it into a subcontractor under explicit terms. He recalls 68 days during the 2022 lockdown when "nothing and nobody was reliable," and draws the lesson he keeps returning to: turn inward, keep what is controllable, build depth. The interview closes on character—how the same person can be optimistic in the day and pessimistic after drinking—and on the detective novels he reads.

## Transcript

### 1. What the name obliges (00:03–01:06)

**R1 (00:03)** — It is not about money. You have to know the front end directly. So this is about a shared management capability and making it coherent. That is how I think we should look at what this company does; I think it is right.

**R2 (00:27)** — Rooted in Shanghai, radiating across the country.

**R1 (00:30)** — Shanghai is what makes the word "China" in our name credible. The spring itself is only my habit. Whether I keep doing it later—I may not.

**R2 (00:43)** — It is not my card or yours. People come to know China Spring through springs. But beyond the card, a great deal of what I carry does not appear on any card. That is fine; it is worth something.

**R3 (00:58)** — And I did not expect that you were thinking this far ahead so early—that you wanted to transform, to move into more valuable directions.

### 2. The loss-making years (01:06–02:23)

**R1 (01:06)** — I never want to live through 1840 again [unclear: he uses this number for a loss-making period; possibly 2018–19]. The company lost money then. If it had not lost money, the general manager's job would not have come to me. When you are losing money you sell whatever you can. That is when you start asking what to keep and what to give up.

**R3 (01:27)** — But why was it losing money?

**R1 (01:30)** — We had a cohort born in the 1970s. The German cohort you mentioned are the same: they do not know that their parents built it. The explicit value was paid for. The implicit contribution—the hidden curve that gave everyone their capabilities—they do not see. They think it was them. So arrogance sets in. We had a few of that kind, or people using the wrong concepts.

**R1 (01:57)** — Because it was a dividend from society, and they took it as their own role. Then society changed direction, and their role began to fail, and fail again. Once you are inside that, the question becomes: how do you get out? Selling is one answer. But after you get out, you keep thinking about those years. I never want to live through 1840 again—stumbling forward, ready to be scattered at any moment.

**R1 (02:23)** — So the question is what we should do next. Within what I can actually reach, what can I think about? And is the thinking right? We have to do some thinking. My view is that it comes back to first principles—what is the thing underneath. There is something else as well.

### 3. The decision to shut one company (02:50–03:38)

**R3 (02:50)** — How long did the losses go on before you found the way out?

**R1 (02:58)** — There was one key point. Once that was settled, the rest of the team also had proof of it. And it moved quickly.

**R3 (03:10)** — Can you say what the key point was?

**R1 (03:12)** — We shut down one company. [unclear] It was not that the business was bad; it was that they could not do it. The orders that [a colleague] brought in, I passed them on to them.

**R3 (03:33)** — So they became a subcontractor.

**R1 (03:35)** — And the problem went away.

**R3 (03:37)** — Right.

**R1 (03:38)** — So should that team have been cut? Tell me. I said: bring them back, I will give you a few orders on the terms we discussed—why would they leave? The rule has to be applied at that point. I did not feel guilty. Because I gave you orders, and at your age, with your history, you should be managing this yourself.

### 4. Sixty-eight days (04:03–05:36)

**R2 (04:03)** — That was 2021?

**R1 (04:04)** — 2021, 2031 [unclear]. What I did was in 2022—about 68 days here [note: during the lockdown]. At that point I thought nothing was reliable and nobody was reliable. On the first day an employee had a fever. We took a car up. The next day we could not drive, so we went through our regional link. By the third day it had to be delivered to 953 [unclear: a site or account code].

**R3 (04:34)** — And that was during the epidemic.

**R1 (04:38)** — Do not think too much about it. Treat yourself as having a fault. Later an employee asked whether the night before I had indulged—watched too much television, eaten too much meat. That reflection is inward. Everything turns inward, to the degree it can. Among all these arrangements, if something is controllable, I will say so; if it is outside, I hope it brings me one more person [unclear]. I was thinking about making a million. Then I thought: if I make a million today, what happens tomorrow? I still have no answer. I need a certain depth, a certain depth of field, so that my child can look after herself.

**R2 (05:36)** — How should one put that? It sounds paradoxical, but we should be grateful for the epidemic.

### 5. Character and its extension (05:43–06:40)

**R1 (05:43)** — And I know this team.

**R3 (05:44)** — Because you are with them day and night.

**R1 (05:46)** — There is this: drink too much—some people are perfectly good normally, and after drinking they make trouble—

**R3 (05:53)** — And again.

**R1 (05:56)** — A person's character has an extension. The more optimistic I am day to day, the more pessimistic I may be after drinking. The more extroverted I appear, the more [unclear] I may actually be. All of that is possible. Because twenty-four hours a day I watch them under all kinds of pressure. So HR—not that HR is [unclear]—at different ages: when we play mahjong for small stakes, I win. But when I play, I doze off. Playing mahjong [unclear], the risk is high, and I am always [unclear].

**R3 (06:29)** — It is a bit like the detective novels you like—the snowed-in manor.

**R1 (06:36)** — You would have to ask me [unclear].

**R2 (06:40)** — I am sorry; I did not learn very much.

*[Recording ends.]*

## Notes for analysis

- The **"social dividend mistaken for one's own role"** passage (01:30–01:57) is the same attribution problem as INT-03's "platform versus capability," stated in generational rather than spatial terms.
- The shutdown decision (03:12–03:38) is described as a **rule applied to a team**, not as a judgment about individuals—relevant to how the firm handles attribution when work is reorganized.
- "**Treat yourself as having a fault**" and the 68 days are the interview's account of what becomes measurable when the environment stops being legible: only what is inside one's control.
