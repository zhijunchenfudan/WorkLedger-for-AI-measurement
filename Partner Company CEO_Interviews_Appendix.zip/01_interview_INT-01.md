# Interview 1 — Control theory, compensation, and what the spring is for

**Project:** WorkLedger — China Spring interview series
**Interview code:** INT-01
**Recording date:** 29 April 2026 (file dated 30 April 2026)
**Duration:** approx. 117 minutes
**Participants:** R1 (chairman and general manager), R2 (interviewer), R3 (second participant)
**Language:** Mandarin. This is an edited English translation.
**Transcription:** machine-generated and lightly corrected. `[unclear]` marks passages whose meaning could not be recovered; `[note]` marks editorial reconstruction. Diarisation was unreliable at short interjections; where a turn was plainly split mid-sentence, the fragments have been rejoined under one label.
**Anonymisation:** the company is referred to as China Spring; individuals appear as R1–R3.

**Note on participants.** The recording resolves to three voices. R1 is the chairman and general manager and speaks for most of the interview. R2 is the interviewer. R3 is a second participant whose questions are mostly factual—capacity, competitors, where the plants are, what robots can do—and who asks *where the factory is* at 01:32:21, which places him with the visiting group rather than inside China Spring. At 08:53, however, he speaks as if inside the firm. The diarisation does not support a firmer attribution, so R3 is treated throughout as a second visitor, not as China Spring's operations lead.

## Summary

R1 opens with his reluctance to take the general manager's job, and with the habit of establishing context before acting, which he illustrates through Detective Conan: science without motive misleads. He then develops "inappropriate technology"—good technology used in the wrong place—through the car industry's capital-driven detour into air suspension, and through the firm's own history from 1937: military springs, missiles, Santana localisation, synchronous development, and a network of former colleagues that later staffed the new car makers. Cheap tools and the Bosch–Volkswagen comparison follow. The middle of the interview is a long account of control theory, modelling, matching and reading comprehension; then the adoption of AI and the handover problem, and compensation as a firm-level strategy. He describes the plan to earn more than 10% of profit outside cars, springs in low-altitude aircraft, humanoids and ultra-high voltage, a technology transfer to Uzbekistan, customers held as a portfolio, air suspension against an electric lift, and closes on the Xinyu training plan.

## Transcript

### 1. The general manager's chair, and reading the context first (00:00–03:19)

**R1 (00:00)** — This is not a job you get elected to. HR—at the time I did not want to do it either. I told the leadership roughly that I would not go; I said I would be dead before I had managed anything [unclear].

**R1 (00:19)** — So it has been helpful. Those years, I think, were helpful. But on the whole the other work was more advanced, and in the middle of a transformation it is rather tiresome. Some departments' team-leading does not line up with the company; every department can be different, and that produces anomalies. Looking back now, from the general manager's chair, and from some things I did in between—the time when you suffer most may be the time when you grow and think most.

**R1 (01:07)** — Even now, when I am considering something technical, I bring some of the human element into it. For example, a meeting I did not attend sends a message back saying this or that is ready. In the old days we would have said: the boss said it, so we do it, right? But HR will ask: what is the context? Context this, context that. It will even go and verify, because personnel arrangements are sensitive.

**R1 (01:49)** — The person who passes a message on will bring his own preset product into it—he may even smuggle in his own goods. We see the same thing in quality analysis and in technical matters. Even someone who looks extremely objective will in the end arrive at something very subjective, but he presents it as an objective phenomenon. So at that point you still have to clarify the whole chain by which the information travelled.

**R1 (02:23)** — Then, through whose hands it passed, and whether that person's understanding of the person concerned has been carried into the business. Only then can you suspect the truth a bit more. What is this most like? Like Detective Conan. To solve a case he has to understand a lot of science, but he also has to grasp motive. If he cannot put the two together, science alone will lead him astray—it will still lead him astray. And motive alone: everyone has motive. With no science at all you cannot do it either.

**R2 (02:55)** — So in fact we have sometimes learned to research this—we call it "inappropriate technology," technology that is not timely. It raises the question of why many technologies are actually quite good, and yet cannot be used, or cannot reach the highest efficiency. At one level, because the technology itself is neutral, but the person using it—

**R1 (03:19)** — Yes. Including what we see now in the national car industry, some of these technologies, air suspension among them, look to me like something capital has brought up. A lot of people have been added in here; it is not that from a technical point of view this is what matches our cars best, right? There are actually many better things. But capital, or some kind of development data—say I work on rubber data, and I want a piece of that too, so I slowly go in that direction. Then capital decides it must frantically show its difference through every kind of new technology. So it is not necessarily the most usable technology, but somebody has opened it up on the wind.

### 2. Inappropriate technology, missiles, and the Santana years (04:09–08:59)

**R2 (04:09)** — I feel autonomous driving is in some—

**R1 (04:11)** — —degree in the same position. Some of it I think is compensatory, a compensation. When I am weak in one respect, I will over-use another to cover for that logic. When my left leg is uncomfortable, I use my right leg more, or my hands, to compensate.

**R1 (04:32)** — Previously we were, objectively, quite far along in many foundations, including engine and powertrain. So we hope people can use new energy and some of the other new technologies I have mastered to make up that gap. And then everything was used up at once. The government happened to need this, needed to convert the energy structure, so it produced these things. But from the technology's own point of view, it may be excessive. Like us—we are an old company founded in '37.

**R3 (05:15)** — At that time it must have been difficult; when I looked it up it seemed rather thin [unclear].

**R1 (05:20)** — '37, wait. But this year it was the textile industry, and in '56 the company—the company must have been—at that time the state was also doing technology models, not just now; and it seems there was no such company that was doing well. Then in '57 it changed its name to China Spring. At that time a great deal was military infrastructure, including electric power and so on. That is how it was; we have talked about this before. We still have a small number of products, one or two, left over from that time. For example the unique spring for the missile—we still make it, and we can go over there later and you can see. The company's history is quite glorious. The eighties were very full. The Shanghai mayor's office gave us an award, the 1979 Shanghai—it is roughly what would now be the mayor's quality award.

**R3 (06:19)** — Yes, yes.

**R1 (06:21)** — And there was another award for a complete set of springs for "peacetime and wartime combined use," which came from the military side. And in the first quarter they gave us something as well. Then later, because we went into cars: in the first quarter the award we got was for Shanghai's car programme, the platform below. Then when [a colleague] joined the team, it became localisation—as [a senior official] put it, anyone with real capability had to find a way to localise. We were responsible for the chassis springs and the stabiliser bar, and once that was done, that kind of car took off.

**R1 (07:04)** — First SAIC Volkswagen organised us, then gradually SAIC. I think from the next stage onwards it was in fact—let us think calmly about it. SAIC Volkswagen built the first batch of localised suppliers. Without that person there would have been no GM to fight alongside, no later joint ventures. Then with GM we set up the earliest technical centre. And in the technical centre the Americans at that time were still relatively open, right? The way they once helped us install radar in our military aircraft. It was convenient then.

**R2 (07:49)** — That is a Hangzhou merchant [unclear].

**R1 (07:51)** — At the time the platform was just—

**R2 (07:54)** — We have taken it on anyway.

**R1 (07:57)** — Two hours. Right. And then—

**R1 (08:09)** — Formerly, as long as you had a capability we knew about, I gave you the drawing and you worked to my specification. Later it was: you must have synchronous development capability, and you must build that up. Then came the stage of the new forces building cars, and everything went up. So with the new forces—especially since I worked at Volkswagen, and I also spent time in SAIC's own brand—by the time I got to components I could basically find my old colleagues everywhere. Volkswagen people, GM people, this policy [unclear]; in manufacturing, R&D and so on, and including logistics and supply chain, a large number of these people form a skeleton. Xiaomi is largely our passenger-car version of that.

**R3 (08:53)** — And we dug the whole lot over.

**R2 (08:55)** — Just because they had no technology of their own.

**R3 (08:57)** — For them, actually—

**R1 (08:59)** — Right. So that was a contribution. But at present the upper level has weakened somewhat. Where has it weakened? In technology, I think. And on technology, at present, I think this is a very good era for us. Even though it is very fierce—but it is not only us competing with others; others competing with us benefits us, and can make up for my own industry.

### 3. Cheap tools, cheap teams, and the Bosch question (09:29–15:15)

**R1 (09:29)** — Why do I say that? Before, a projector—across the whole company, each one had to be economical. Now if I want a hundred of them I do not blink, because it is too cheap. And the televisions: I remember when we were at Volkswagen, which had money, the canteen television was a plasma, not big, about this size. A hundred thousand yuan. Now with a hundred thousand I could cover this room in screens. So if your availability is strong to a certain degree, places that could not be innovated before—now many people can do it. Like me: when I could not write code, and now with natural language, through AI, I can already program. Or it turns into: I can complete a relatively complex work task, right? Before, at most I could write a macro and mess about in Excel.

**R2 (10:27)** — Then for you the biggest—who innovates, who gives you the biggest actual return, is you.

**R1 (10:33)** — From which—

**R2 (10:34)** — —place, which segment is actually most easily affected.

**R1 (10:38)** — This goes back to what we did not say earlier; in our [unclear: internal college] there has never been a reply on this. So on this philosophy, on horizons, and on this, we may have to look for some compensation. If we do not compensate, that place cannot be saved.

**R1 (10:55)** — On the one hand we must find a way to change the thinking, change it; if it really cannot be done, change the people. That has to be done. Because I think of myself: all entrepreneurs, or CEOs, or leadership teams—what they are actually doing is enterprise reform. Do not put the cash posture in front of it and drag it all up together. There is no such thing as an enterprise-type team; there are only entrepreneurial teams. That is my view.

**R1 (11:26)** — For example, my child is a rich second generation; I am the first generation, I fought for it. Then in the direction I fought my way into there are also two directions: one is eating, drinking, gambling and selling off value [unclear], and the other is that he also wants to work hard. But when my sister speaks he has to listen, right? As long as my sister is only a department head below, or finance—[unclear: the passage collapses into repetition here] there is such a process.

**R1 (12:01)** — Our state-owned enterprise is the equivalent of a rich second generation. Because not one cent of the first general manager's money was earned by himself; it was not invested by the parent body either. He can afford to make mistakes. When the system is not sound, when the social direction is bad, when the individual's number is not enough—of course he can also break through, including against the parent body's various departments and institutions over his money, the government's demands on him, the pressure of GDP. Breaking through that, he can do the same things. Foreign companies: what we see now is that foreign companies are the backward productive forces. Foreign firms, state-owned firms, especially Japanese—the media [unclear]. Media and Japanese firms and German firms: some of them are actually backward.

**R2 (12:44)** — On this, I also wanted to ask everyone. So the situation you just mentioned. And the Sino-German joint venture—we actually went recently with Bosch's global brand people. And one point people raised is that of the many German firms in China, Bosch seems to be doing somewhat better.

**R1 (13:06)** — But firms like Volkswagen—

**R2 (13:08)** — —in some cooperative situations are worse. So we asked him one question: from a German's standpoint, how does he solve this? He gave me an explanation. He said the reason Bosch is relatively good is that Bosch very early—

**R2 (13:22)** — —began doing R&D in China on its own. And in that situation, he said, there is a problem: you have to wait for the place, and it is very hard to drive things globally. But looking back afterwards, he had bet on a guarantee: that the Chinese economy would develop, and that Chinese car ownership would certainly rise. So rather than using the German model to match the relationship, better to make good use of localised resources in our company.

**R2 (13:47)** — So you think this is the same kind of thing as Santana?

**R1 (13:52)** — I think so. That localisation, from the parts angle there is some, but from the resources angle there is also one. Actually I think localisation should be thought about this way. From the standpoint of running an enterprise, I will certainly find a way to make the long board longer. The normal short board—either I control it, or I let it grow, or I suppress the risk; roughly enough is enough. On localisation, we used to be unable to say that localisation is only for cheapness. Culture can also be for speed, for this, for all of these things, for efficiency. Because Chinese people, our R&D provided that target. Electronics, including chips—their engineers all work across three shifts [unclear], TSMC.

**R3 (14:48)** — They say the Americans especially cannot stand it.

**R1 (14:52)** — Our Chinese ability to learn is especially strong. Whatever maximises efficiency, they will go for it. But in Europe and America, at their base level they simply cannot accept it. So I think rather than that, better to do it over here.

**R1 (15:15)** — Of course this depends on the big boss—on what the real big boss of a Chinese company actually thinks. If in his bones there is a kind of conservatism, he will not do it. So I think Bosch's contribution as a team—we have seen the same thing—including some of the neck-choking [bottlenecks] and so on. Whether they can go there. And last week was the auto show. I did not go, but I have too many round-trip issues with Mercedes; they are very anxious too. But that anxiety of theirs—they cannot find the method. And they do not want to survive by changing; they still want to do these things through some kind of dosage [unclear]. It is not: starting from the top, "I too must set out on the long march again." There is no such idea.

### 4. Control theory: fire first, then correct (16:13–26:17)

**R1 (16:13)** — And in their bones, how to put it? They feel the threat, but actually they are only anxious; they do not really have the heart—there is no real [unclear], it is all a mess. And the centrality of human nature—they have not even reached that process. They just say I am very anxious, I am very anxious, what should be done? That is their state now. So what I am finally saying—let me talk about China Spring first. China Spring, these two years, we have relied on rapid iteration. This is some of the thinking from cybernetics, from control theory. What does control theory say?

**R1 (17:00)** — Do not be perfect, but have an ideal. The ideal is that I want to hit that aircraft. Perfect would be firing the shell and hitting it first time. That is actually impossible, because everything is dynamic—including my accuracy, including the wind direction, all of it is dynamic. You cannot design a perfect formula, fire, and hit that aircraft just like that. A manoeuvring aircraft is dodging your shell; you cannot even hit its name, because it is moving inside such a large volume of airspace. It has to be like this: I fire first, I see how much data I have on him—I have that much data, so I chase, because my speed is higher. Then after I chase, he swerves and stretches out again the distance I had just closed. Never mind: I turn and chase again. That way, in the end you will probably—

**R2 (17:47)** — —reach it. Attacking an aircraft carrier is this thing.

**R1 (17:51)** — That is idealism, but the price gets larger. So I think we are actually moving in this direction: we will correct the goal dynamically. But first, make ourselves fast. And how do you get fast? You have to let the vehicle run.

**R1 (18:07)** — So the thing you said you were particularly interested in—I do not think there is [a plan]; I now watch a great many short videos, and through the short videos I look at the educational value and the maturity of a technology, to analyse roughly what level a certain class of technology has reached, which things have fallen to a cabbage price I can afford, which technologies I must watch—expensive or immature now, but I must keep up. So my understanding is that our technological development should be the great synthesis of industry: everything can be taken and used. That is also why this afternoon we are talking about the machine problem. And later, since it is raining today and we will not drag everyone around, we can go and look online at some of our production situation—and this industrial robot achievement [unclear].

**R1 (19:01)** — Take Hikvision, which is quite formidable now. I would want to use it for our measurement. I would not go to them on my own initiative and say: do not just do surveillance, electronic fencing—what is your precision, can you actually measure? If it can, why should we not cooperate? There is no reason. And take the laser—what could I use a laser for?

**R1 (19:30)** — Our spring is coiled, and when it comes out it has to be cut. When we cut it there is a void inside. I say: can you cut it for me? Or we have those especially thick springs whose end has to be ground flat. Think of Li Bai as a child with the iron rod, grinding it—you have to grind half of this thing away, this big. The noise, and the efficiency, are all very—. I say: you, including a water jet, including cutting one pass with a first-class pipe—then my grinding allowance is actually much smaller and the efficiency is higher. So I think development from the technology angle is precisely this great synthesis of industry.

**R2 (20:12)** — If I go and understand that many technologies, there may be [others]. But for example, besides lasers, for instance high-speed water jet impact—that has not reached this effect either, hypothetically.

**R1 (20:23)** — Right, right.

**R2 (20:24)** — So why choose laser and not the others? What is in there?

**R1 (20:28)** — Value maturity, and matching us. For example, my wife is not as good as that former girlfriend in another country, but I do not want to match with her [note: he means "match" in the sense of fit, not of quality]. She and I simply have incompatible eight characters—not that she is bad, nor that I am bad; our eight characters just do not match. In my case, for instance, I need rust prevention, so I avoid water wherever possible, right? Although I tried it, and afterwards I found the stainless treatment brings problems later on; we do a comprehensive evaluation. But how it is actually done in the end, and which industries to know about—I think that is what the teacher should be doing.

**R1 (21:13)** — Model. Turn everything into a model, and on the basis of that model say these two are one model. Management is liberal arts; I am science and engineering. As long as we are one model, your liberal arts can give it to me. Let me give you an example of what a model is.

**R1 (21:31)** — My understanding—you all know the genetic algorithm, right? The genetic algorithm means finding him a son or a grandson, right? I hope to improve somewhere while at the same time hoping to move it toward [unclear]. In the end I find some of these things have only this many terms, and this many terms, and that many terms. I hope it will be more alike, and I hope this place will be longer and longer. For example, is comparing over the telephone this genetic algorithm? The genetic algorithm probably came about because biology crossed into mathematics and algorithms and produced a model, right? For example, I have a cousin. I told him: my table is an old lamp [unclear].

**R1 (22:20)** — "Old lamp" [note: internet slang for an old person] means that once your technical level drops, what you like is different—he likes playing with walnuts. Walnuts over time get a patina, and then they are quite nice. He is idle with nothing to do, so I went with him to Tianjin, to that antique culture market, whatever it is called. He would probably see at a glance that this shape is quite good, take it in his hand, and start matching. Compare it with that one—maybe he finds a better one; if not, he finds a pair like this, say fifty yuan for the pair. So what is the essential difference between that matching and a computational algorithm?

**R2 (23:07)** — Actually this carrying it on the back [unclear].

**R1 (23:08)** — The process, right, is one of matching. So the real model is matching. Once you recognise this, in the walnut field I can also do it; in the genetics field, where I do genetic algorithms; in the detection field I can import it. Laser then, whatever it is, including this one. I think when something is a model we should model it. So when we talk about human resources, I tell you: the most basic literacy of our cadres—we call it reading comprehension for the backbone—sounds as if it leans toward the liberal arts, but it does not. It may lean toward emotional intelligence, it may lean toward science and engineering. Everything is reading comprehension, including today's large models—not large models, including AI; its first step also starts from [unclear: possibly "from zero to one"]—our children also grow from that starting point.

**R1 (24:08)** — So what is reading comprehension? An example. A group of us, not very familiar with each other—we try not to do this, but we have a meal. How do we quickly find the position we should take and avoid the awkwardness of the position we should not take? Is that not a common problem? Not to mention: given the context, what should be done about this matter? And context does not have to be text. Context may be the cause and effect I just mentioned, who passed on the message, what expression the leader had—combined with what I imagine I am doing. That is probably the management side. And our technical side, as we just said, also combines context, and then seeks the scientific principle, the motive, the driving force. Once you have done these things, it is a fluid thing.

**R1 (24:57)** — Reading comprehension, in the end, I think is modelling. Why? For example, someone from the humanities will write a thesis—for instance on the round table: attending a core event at a round table, the logic of choosing a seat at that event. It is on the basis of that logic that he builds a model. I think that on the basis of these models we can then do more things.

**R1 (25:34)** — And the aesthetics of this place—aesthetics is not just how I handle traditional content; it is actually about being reasonable. I think it is economics. For example, watch whose movement: that procurement man plays golf, [unclear: Michael Jackson's ...]; another bought to play basketball. That beauty—anyone can appreciate it, right? We are certainly not looking at whether the ball went into the hole, or whether his movement is precise to this degree or that. I feel: the score is just so, not one point more and not one point less.

**R2 (26:15)** — It is like the golden ratio in mathematics.

**R1 (26:17)** — Yes, there is a principle in that. Right, he already has this kind of principle. So I think if you add these things, then in the end what comes back, I think, is the control system.

### 5. Adopting AI, and the handover problem (26:34–36:20)

**R1 (26:34)** — For our part that will be better. And AI. I very much agree with what was said today, so I also want to embrace it. So in '24 we were watching; in '25, once DeepSeek came alive, it strengthened us. So in June we localise [unclear]; then around July our first-generation attempt came out, and now we are on the third and fourth generation.

**R1 (27:05)** — Why am I comparatively keen to do AI? One reason I mentioned: I want to go out well. My other aspects, my management, are probably relatively weak; my sense of process is relatively weak. We often notice this in daily life—Huawei, this business. But in our work, because it is this kind of routine, this science, the long-term training is not enough. Now we want to have people help us. Of course at the beginning AI could do things for us, but later AI became a little assistant: "help me bring that thing over." He is more controllable. Although AI hallucinates, it is more controllable than some of our immature employees. And the key is that he is controllable: what you invest in him—if he gets it wrong and you go and correct him, his IQ slowly rises.

**R1 (28:04)** — But some of our employees—although we want to look at people dynamically, not to write a person off—some employees really do hit a glass wall. And we also have some daily pain points. For example, [a colleague] and I are like brothers, and it happens that I am to take over your post after you. We are like brothers, and when you hand over to me it will certainly be to me.

**R1 (28:34)** — Right. But what is in that handover? You tell me what I am to do today, what tomorrow, and that recently I am on such and such a project, and roughly by then. But very likely, when I take it over, I do not care about this thing, because it will be pushed along by the project and people will naturally come to me. I have no project manager; anyone at all can find me.

**R1 (28:58)** — That is actually not the important part. What is important is that the thing you did before, the thing that is already closed off [unclear: possibly "nailed down"], you did not tell me thoroughly. I feel that what I am facing is precisely the things you did not tell me, right? Even your predecessor's predecessor's judgement at the time—I see it here.

**R2 (29:15)** — Yes, this tacit knowledge. What we call the many explicit things are actually very easy.

**R1 (29:23)** — On the metaverse, I have long said that for me the best thing about the metaverse is [unclear]. Mine is relatively early. I think if there is a reason, for me it is that I want to chat with him; once I chat with him I want to see him, and I can see him, even without physical contact, right? I think that can be with them. Actually, for a company—we now take the whole company. So including these visits we do, the design surface is relatively broad; we are willing to help you experiment for free.

**R1 (29:58)** — Why? Not that I want to drag this voice along; I treat this as a corpus, as my own experience becoming more and more complete. The more you explain, the deeper my understanding of this thing—like what you said: I am now [a colleague]'s boss, and looking at this enterprise again, of course I see it more thoroughly, right? So the fuller my experience, the more—we have some agents; for example, this one thing is just a task, filling in a form for the government. I treat it as a skill, or call it as a workflow. So we are now reorganising the whole thing along these lines.

**R1 (30:44)** — If we organise along those lines, why do I say it connects to us? Because when we were doing smart manufacturing, I was already thinking about this. Although I have been in this for so long, the work is in my hands, roughly a thousand people across companies and posts, and I have certainly seen it—but I do not think this is an attack [note: he may mean an accusation]. As I said, we should regard this as a kind of guilt. What is guilt? The organisation could not take care of him; or the organisation over-used him at the time; or afterwards the organisation could not bear him; or in the process the organisation could not bring him along, could not lift him along with it. So I think it is a kind of guilt.

**R1 (31:36)** — When I became general manager in [unclear: possibly 2020], we used to have over 1,800 people, and up to five kilometres [unclear], and in the end we had companies that we closed. Now we are about [unclear] and there are not the same people as last time. I also want to keep this scale, and advance through capability improvement—and of course through structure and systems. So it is impossible for me to say that I protect the company's fundamental interests; does that represent protecting every person's capability, right? Those who cannot do it, who cannot keep up—I should pay them out; if your knowledge structure does not work, I certainly will. But on the whole I hope—there still has to be this kind of important heart in doing this thing.

**R1 (32:26)** — Now, on people. First, as I just said with control: I want you to have a certain ideal, that is, in the goals you set you need a sense of goal, of what you are doing. I do not only make demands on you; I give you tools that help you meet the demand. For example, for my son, who is 1.3 metres, I give you a step. Then you find a way, through your skill, to improve—and then we do something at a larger scale. Right, that is how it is. Our equipment is the same now. Our robots: once you have seen a lot of them you will find, if you sum it up, that more than 90% of most machines are simply carrying things, right?

**R3 (33:12)** — Some other plants say that robots replace a great many processes, and that it may be a question of cost. You are saying it is not like that.

**R1 (33:22)** — No—what is it then? Our tasks now are different. You see, most robots carry material A from A to B, and then special-purpose machines do the work, right? Of course that is the 90%; the other 8 to 10%, the robot is already machining, already processing, right? So it has already advanced; its co-pilot is done. Before, it replaced a logistics function; now it is equivalent to replacing an operator. Can robots go further—commissioning, changing over a line, changing to new ones? Going up, by about June this year we will have machines with this 3.0 function.

**R1 (34:13)** — At present we have two [unclear] processing definitions in our time—I have two units—and then the same processing; this is us together with FANUC, we share the intellectual property. And that person is the same. But I think that when robots reach a certain point the problem is indeed a large one. When AI reaches this place there will certainly be some per cent.

**R2 (34:41)** — Let me ask: after FANUC got to 2.0, and then to 3.0, what is the main difficulty it meets?

**R1 (34:46)** — The challenge? Product I cannot [judge]. What he says—I think there are still four, what kind of thinking. He does not have it: he stands inside the robot to look at AI; he stands inside the robot to look at how the era progresses. At that point you have to jump out of the machine. First look at the era; though what you see may be wrong. The way of thinking I mean is: I first jump out of my own job—I make springs, what do I do—I am willing to jump out.

**R1 (35:16)** — I think you have to let them look at where the trend is going. For example, in the future AI means intelligent equipment, and intelligent manufacturing moving in that direction. Over there I will first quietly go and study in that field, and after studying, close the loop back to the robot, or to my spring. They only stand inside my gang or my robot and ask how I follow this and produce a view, and what they close the loop on directly is their business volume, sales and profit. I think if you do it that way, you are very easily replaced.

**R1 (35:53)** — That is the thing we mentioned—the incredible technology, the untimely technology—it actually comes from the question of original intention. So at the time you were standing inside the cup, looking at the sky like a frog in a well, and you will produce a great deal of unsuitable technology. But if you suppose you put a drone out, you stand in the sky and look, you finish looking from many viewpoints, and finally you close the loop back on my scene—I return a few years later and do what? Then your idea will certainly be different.

**R2 (36:20)** — Right. So it is a bit like an AI-plus problem—one AI-plus.

### 6. Compensation: knees, information systems, and buying capability in (36:24–41:31)

**R1 (36:24)** — Right, yes. So we hope to be able to jump out and look. Because, first, my team needs this compensation. Because our information system is actually above our industry—even above my automotive [customers]. I was in certain places before.

**R2 (36:41)** — We tell him—this is what we are especially curious about.

**R1 (36:44)** — Why are we above them? Because I need compensation. For example, my knee is bad, so I have to compensate for this deficiency of mine.

**R2 (36:53)** — But this is only the concentration—I mean that this awareness matters. But being able to actually pull it off in the end—

**R1 (36:59)** — —is not easy. Those who can do it—we are fast, rapid iteration, we probably—

**R3 (37:06)** — I think they may not be suitable for cooperation. Which companies do you think could be partners?

**R2 (37:13)** — Those who have already reached this awareness—

**R1 (37:17)** — Me—right, yes, that is how I am. I spend more than three days a week out running around, and I very rarely go after an order or a piece of business. Say a courtesy visit, or actually most of these—including this whole customer set—I am underneath them all [unclear]. Everything I say is really HR work.

**R2 (37:40)** — Right, that one. Right.

**R1 (37:43)** — What we call it is really still "controlling people": you know the main thing is to assess the channel, do not look at the school. You look at our industry-university-research before—they never looked below 211 or 985; above 211, they never looked. I think as long as the person is reliable at doing things, and he thinks the same way I do, the same way our team does, take him. Of course, once we reach a certain standard, in this area you must look among the 211s and 985s; there is no way around it, right? Really no way.

**R1 (38:20)** — This year we may set up a joint laboratory with Jiaotong University, and with Zhejiang University a new company in robotics. So this year. But in previous years we looked at Wenzhou University, the University of Shanghai for Science and Technology, Shanghai University—roughly we looked at Shanghai's [unclear: "1-1-1"], right? Beyond that the question is only whether they do things pragmatically and reliably.

**R1 (38:48)** — Then AI. We also have part of it in-house. Early last year we trained one AI trainer, then another one. At the beginning there was nothing, because at that time we did not trust AI enough. So I said: anyway, just interact with it all day; if it goes well we are happy, and if not I can understand that too, right? We do it through interaction—like Einstein making a few little stools: how does it feel about the little stools? Then off you go. But later we felt everyone was reliable. Fine, so we went with the Yangtze River Delta Tsinghua research institute, and found them through their guidance. And the teacher who actually does this is in Germany—a teacher in Germany; it is like climbing a mountain, and then he does some of this for us.

**R1 (39:43)** — And the cooperation philosophy I mentioned: because our accumulation was not enough before, it was 1,000 yuan at a time—today I cooperate with you and get a little bit of feedback. Because [a colleague]'s 2.0 may be the collaborative version. The 3.0 version and the future technology industry chain we will keep here, with me. Anyway, the three of you do not necessarily need to know that I am cooperating with you—you and him—

**R2 (40:49)** — Because the scale is different too, and what one does is different. Yes—like eating at the roadside before, that was fun, but now that more people are at the table it is different.

**R1 (40:59)** — Yes, but there is no help for it. Still, I think I will keep the earlier ones going. Why? First, I treat that teacher, or that school, as a day's agent system, right? This agent is just equivalent to being opened up in the code. The agent—I will keep raising it, right? But now, if you and I can cooperate, this agent is my inner-ring agent.

**R2 (41:31)** — That actually makes a lot of sense. That is, recently we have been studying OPC, the one-person company. The first stage is really finding demand. The second stage is looking at the proposition—actually you have to get to experience. The third stage is building the ecosystem. So from a business point of view, for OPC, if demand is uncertain then this thing is roughly—but by the second stage it certainly has to be able to iterate.

### 7. Ten per cent outside cars, and where the spring actually sits (42:03–55:51)

**R1 (42:03)** — We—never mind them. As long as you are fast enough, then we play the direction together. I was slowly [unclear] them. Our company has been like this: the previous twenty or thirty years, unchanged, like a single day. Because we—[a colleague] and I—in the last half year, every day; not exaggerating, every day.

**R3 (42:35)** — Wait, sorry to interrupt. I feel your ambition is no longer confined to the auto industry. Are you thinking of expanding into other industries? Is that how it is?

**R1 (42:47)** — We were already like that before. This year should be the first year of our return to beyond cars. My definition of a first year is that more than 10% of my profit comes from outside cars.

**R3 (42:59)** — Before, it was 70%.

**R1 (43:02)** — What is it? Basically over 90%, apart from the eleventh [unclear]. Because at the time it was too good: all the energy went below you, and the main business was forgotten. Originally I also did completion work, I did whatever; then I said I would not do it. We are actually equivalent to—in Gucun, we took over that place; we are equivalent to Gucun Automotive Chassis Spring Plastics Co. Ltd. So I told him: do not be afraid, we are called China Spring.

**R3 (43:25)** — This name is not—

**R1 (43:27)** — It is neither China nor China Automobile Spring, right? We are China's, right? If you do not go abroad, you cannot represent China—would you agree? For example, another of our companies is not called China Spring; it went abroad, so it can represent China. At home I say I am from such and such a place; abroad, the first thing people ask is whether you are Chinese, right? Yes. So that is one thing. And then: you can only mix about inside cars, and your scene is first of all that the flatbread and fried dough sticks are delicious. But we cannot raise a child on flatbread for a lifetime—that is how his nutritional structure comes out right.

**R3 (44:09)** — So does new energy mean demand for springs will fall?

**R1 (44:13)** — Not obviously—it increases, if anything. What increases is that it gets thicker, because the car got heavier: the battery and so on are a bit heavy.

**R3 (44:25)** — So new energy is actually good for your company.

**R1 (44:30)** — It is not that there is no nature to it—this is narrator [unclear]; it is not that there is no dramatic or overhead effect, how to put it—no such influence. We should be counted neither as a sunset industry nor as a sunrise one. We are like energy: it is traditional, and it depends on the innovation you put into it. Anyway, whenever it exists, it may take different forms of deformation.

**R2 (45:02)** — Now a lot of these people—the new forces, the car makers—are all running into the low-altitude economy. Is that an opportunity for you, or what? Now we have got as far as cars.

**R1 (45:16)** — I have got to aircraft. The low-altitude economy I think is an opportunity. We have been following it since '24. But the first thing the low-altitude economy solves is a bit like what new-energy cars solved first: the range problem, and trajectory planning. Right now they have not really brought cost into it, because there is no cost, no economics, and no [unclear] encroachment.

**R1 (45:46)** — Right, I think the low-altitude economy, and humanoid robots too, have a long road ahead. On the technical path, or purely technically, they have a great deal of road to walk. And that road is one where, after they have paid the tuition, they must change.

**R1 (46:04)** — Because look at the mobile base—generally, what kind of people produced the low-altitude economy that people talk about this month, and what kind of people are making the noise about new-energy cars? Most of these people are mainly control and mechanical. Some are on the soft side; they do not understand hardware, and if they want to turn into that—you cannot be like Hawking, who had only the soft side; with both soft and hard there are obstacles. You also cannot ask someone with an IQ below 80 to [unclear] at the top like O'Neill; in the end it should be a relatively balanced person—IQ at [unclear] and emotional intelligence relatively equal. Only then is it possible.

**R2 (47:00)** — Because I am relatively soft myself, so I just want to experience it. When we say from control to mechanical—because the mechanical I understand has—

**R1 (47:09)** — A great many of my classmates work in control. You all drive cars—your car now basically has an electric tailgate, right? An electric door: is it not driven by a motor? It opens, you get out, and then it comes down with a bang, right? Do not look down on this mechanism; it is well worth the car and the robot paying attention to, because there is no spring in this mechanism. I will talk about it from the spring's viewpoint. Right—it is not that it has no crucial role in letting it out [unclear]. Think about it: the door is so heavy, the tailgate is so heavy; when it comes down, do you not sometimes have to prop it up a bit? Otherwise gravity takes it down, right?

**R2 (48:00)** — Dangerous.

**R1 (48:01)** — Actually there is a spring inside. It is compressed, and once compressed it holds. Then when you flick the switch, what starts at first is equivalent to a hybrid: motor plus spring. The spring is still compressed, then [unclear: "610"], so at start-up the motor's power draw is actually very low. Only once the spring is fully extended does the remaining bit depend on the motor. How much work does that save? Now look: where do a great many robots put their energy? They put a large amount into—

**R3 (48:45)** — Heat dissipation.

**R1 (48:48)** — Why heat dissipation? Because the power draw is high, right? Then they have to solve the heat, and the more complicated the heat solution, the higher the power draw is, in theory, right? Because it is like dealing with rubbish: if you do not go to the source—how do I make it draw less power, so that I generate less heat—if you do not solve it from there, then the untimely technologies will only multiply.

**R1 (49:16)** — Something similar—let me give another example. I am crouching down now. Suppose I am a humanoid robot, and I am playing the piano. A child playing the piano is neither properly standing nor properly sitting, and his hands are always there; his precision is actually in his hands. Right, at this place you can do whatever you like: ball screws, or just motors, any motor, winding, anything. But actually what I do not solve down below is the precision; you should solve the question mark.

**R2 (49:45)** — Right.

**R1 (49:46)** — And leave this as the work. Right, this one is for precision; it is only a platform. At this point, when I go down, you see, through my—

**R2 (49:58)** — —potential energy, kinetic energy, should—

**R1 (49:59)** — —exactly. When I stand up it gives you a push; it is equivalent to propping myself up on a stick and getting up.

**R2 (50:07)** — So without this mechanical understanding, to a large extent you simply cannot become aware of this thing.

**R1 (50:14)** — Because the real mechanical masters in the world, as you would put it, should be in America [unclear: possibly "in the US these days"]. Do not be fooled by how clumsy American things look—the mechanisms; the German ones are more precise, the Japanese more refined, more compact; you must learn from them. This is a lesson I think we have to make up, and it is most concentrated in cars, right? Mercedes—the structures they design when they design a car, some of those things really are—not that they look like works of art; you look at the concept and it is simply beautiful.

**R2 (51:02)** — What you said just now about the two people handing over: after the foreign enterprise came to China, China only got the last part. But when you work backwards from there, a great deal cannot be worked out in one go.

**R1 (51:11)** — Right, so many years—

**R2 (51:13)** — —of accumulated things.

**R1 (51:14)** — So we may very well produce a great many AI masters, masters in certain respects. But on this we must keep going with another kind, to keep us balanced. That is, my robots—as I just said, to do robots well you also need the industrial-level master.

**R2 (51:40)** — Can this use your—

**R1 (51:41)** — —the compensation thinking from just now?

**R2 (51:43)** — That is, I know I am probably not good at this, so I use—

**R1 (51:47)** — AI to help me carry the long board. AI carries the long board. But I mean the basics. For example, you—because you are still continuing. Compensation is generally of the same type compensating. For example, a lack of physical strength: I cannot rely purely on mental strength to—

**R3 (52:08)** — [unclear: possibly "in the field it will be the new one; not that the parent company deals with the agent"].

**R2 (52:12)** — What I have seen—for example, is it not the case that AI is now used to design aero engines, a single engine, and the designs come out quite good? Has it [been done]? Yes, yes, yes, quite good.

**R3 (52:23)** — This is a very core one.

**R1 (52:24)** — China—you would say this belongs to that period; it is derivative, derived onto manufacturing. The designer made it; he also made it at the designer's, and he used it to complete a design. Without 3D printing I could not support you either, so there would be a pile of problems; whether it can be produced—this is compensation. I think 3D printing versus traditional sand casting: this is casting; then the AI design is replacing my original traditional-thinking design; this is the compensation, right? At the design level, yes: 3D printing has replaced the precision of sand casting.

**R2 (53:03)** — Right, but there is no way to put that compensation in. For example, yes. So the logic of this thing is only this logic, and different logics cannot be mixed in as compensation.

**R1 (53:13)** — Perhaps there is, but I think most likely it is—for example, at the level of ideas we can compensate. Right, at the physical level we can compensate now, but at the level of ideas producing the physical—that may have to go to metaphysics. But I think in future, with quantum and so on, maybe I use thought to do that; I increasingly think it is feasible, increasingly feasible. Really: everything we say about springs—what we studied ultimately has to answer the question of using the spring to understand the world. Though what I just said belongs to doing the landscape line [unclear]. Because I think perceiving the world is all done through what we are best at; I think it is very—you look at the robot path now: some people rely on mechanics. He says I am a bit—I think he is busy, so I rely on mechanics, I dare not [unclear]. Now look at our mechanical hands, the marketing hands—they all have to hold the cup like this. Right, the person who is really good at it just hands the cup over, does not sleep, and then I can hold the cup like this—actually it is the same thing. Why must I have standard things? I know this region is also well controlled; most of the time, why must it be like this to be elegant? That is—

**R2 (54:27)** — We will be elegant.

**R1 (54:28)** — Right? Mm, mm, mm—it is also a way of knowing. And for example my rules, this way of knowing, what vision is—this is also a human thing that everyone can do. But I think the real humanoid should not simply be a human; the humanoid should be the entrance to the senses. For example, when the two of us are chatting here, everyone walking past outside is opaque to us; it should be in our hearts. And many of our current plots—we chat, and it is chatting with you, and everything else cannot be switched off.

**R1 (55:10)** — So now we are making some attempts. For example our sweeping machine—our sweeping robot—I can fit some sensors: a bit less of my noise, the temperature, and whether that place has an anomaly. I think it should be this kind of integration; it may be the goal of innovation right now, and also the best way for us humans to coexist with robots and AI before that era arrives. We go through scenes, through building some of these things for it, through engineering.

**R1 (55:51)** — So now ours—whether our smart manufacturing or AI—we are working toward human-machine collaboration. We take what people are best at, and let the equipment keep being the stepping stone for you. And at the same time you give it more content, so that we become partners. So when my strength is greater, I intervene and lift it up. But up above it does for me what I cannot do, and then lets me grow and calculate; we hope to become this kind of real ecosystem. So at noon we cross-check documents with each other [unclear].

### 8. Digitising the spring, and the problem of releasing people (56:36–01:04:15)

**R2 (56:36)** — Last year I went to Yaskawa Electric, and they were still talking about this. What they wanted was to put chips on all the small motors, precisely in order to collect more information.

**R3 (56:49)** — I think it is only their cooperation with Nvidia.

**R1 (56:51)** — Right.

**R3 (56:51)** — This is also because—for us—

**R2 (56:53)** — I do not know about him, because I went first and then they released the news; at the time I was taking people to talk with them. He said the reason he is doing this is exactly what [a colleague] just mentioned: pre-burying for the next generation. He wants all the data from his [unclear: possibly "gripper"] to be captured.

**R1 (57:11)** — We are the same; we are actually doing it too. Now I have a great deal from the spring's own angle, so we are also transforming: in future we will not take the product as the platform—we are called China Spring. Before, it was product, that kind of technology, and then the composition of technology. So we—on the basis of data, and of locality, once we have this data, what we do now is that AS [unclear], and later it can actually be in the form of a neural network, letting it also—as we said, once I reach a certain point, once the data accumulation reaches a certain point, after that it naturally improves. That is, perception tells me I should do it this way. Then you can know my commissioning—our commissioning now is like this.

**R1 (58:08)** — The first step is to digitise it entirely, one spring. Do not think the data is small; just think about observing this thing—the unfolded length is quite long. Today we use scanning technology; I photograph it, and that technology produces the whole profile. Between that profile and my ideal profile, the main thing is the cost of control: with the data I know how to correct it, and then it tells me. We are researching this, and we have produced it. Once it is produced we translate it into the language of our coiling machine. Then we instruct the worker: push it that way—you need not be able to [unclear]. You only need to be able to do some of the operations in front, and then he can do this much. This has already reached the level of the mid-to-senior aviation [worker] that needs three to five years of training. One idea: those of us sitting here, as long as somebody gives us a hand, follow this logic—two hours, one hour, maybe half an hour can reach something that took three or five years.

**R2 (59:14)** — I had this feeling after I got to customs [unclear]: when they stick on the positive and negative electrodes, what [a colleague] just said made me think—Chinese manufacturing has one thing. Originally, from my shared standpoint, this was something I did; now I do not do it. Now I watch him do it. But because a lot of the time, when they apply the electrode well, there is always a little bit of a lunge, just a little, and that may be a problem. In future maybe I am not watching—that is, if there is a whole process, I default that he does not [need me], and if something does go wrong, I wait for him to call me.

**R1 (59:47)** — Then I go and do it again. Right, right.

**R2 (59:49)** — From seeing to doing.

**R1 (59:49)** — Right. That way one person can watch a great many. Second is our commissioning workers, including the one at that motor: in theory this person is the most [capable] in this population, and this tells you that you should release him. If you do not release him—as I said, you cannot use other people like work shoes. Because he is useful, you keep treading on him and never let him move. You should be like this: since he is useful, I should want him to give greater value. That is ours—there are people like that.

**R2 (01:00:23)** — There is a problem from the human resources angle. This person is so useful precisely because he only does this kind of work; in this kind of post his capability is the highest. If you release him, then to find another at his capability standard—you may not find one, hypothetically. Because if in the end everyone is at my production condition, what I see is, say, this person is at this post, but the person at that post has capability left over—I actually have no way to shield the conversion.

**R1 (01:00:51)** — You see, this will also become overcapacity; then the data becomes easy to sell, so I expand—I want more scenes. Right, I want more scenes. Now, for example, our spring people, right? His level is high, he is very sensitive to fine adjustment. If we had not been civilised enough earlier, then you would go and learn, still selling according to this set. Second, you are still the home room of my spring—what does that mean? It means that here, say, the machine still has a bit of a problem and still cannot reach your level. Because it can only be intermediate and you are top, you are the very top, so you still have to be called. In that way I have actually made his post more secure.

**R1 (01:01:33)** — Also, this is what I tell them: some of our human resources work is about being compatible upwards and downwards. Only wanting upward compatibility is no problem, but the trend changes and then our policy pays out instead. Only downward compatibility is also mutual, right? We must find a way to find this upward line to connect.

**R1 (01:01:56)** — An example—what I just said can also go downward. The main networked person today—we are not the ones who get poached [unclear]; we are often poached, and once they have stripped me, this piece of business of mine—because I trained—it is equivalent to my training someone for five years, and he goes over for double salary plus 50%; those five years of mine are equivalent to helping them.

**R2 (01:02:19)** — He was helping him with something unforeseen.

**R1 (01:02:21)** — Right, my headache was taken away by him. They used him for two years, tuned him up, and then they will make him a [unclear]. Then is it possible—for him, I think his career will also enter another phase. Of course it is also possible he starts a business and becomes the richest man; all possible. But he will become another state. For me, both the explicit and the implicit are in the learning, but now I do not need to worry. I do not need to worry about this now. What did you do? I just did these things; even a novice can do them. This is the same as handing over work: he has already handed it over into the AI—no, no, into the AI, in my system.

**R3 (01:03:09)** — The hard skills inside should not yet be shown, [unclear].

**R1 (01:03:14)** — You mean our soft-side people doing these extreme things on Taobao, because we cover a broad surface, but every point is difficult, right? We are not doing embroidery, sewing on a button. This button business—that is what I want to solve; it is still smart manufacturing that solves it.

**R2 (01:03:38)** — This is very easy; this is a typical case of AI brute force.

**R1 (01:03:42)** — Right. So I think my product has no way—why do I do this robot forum? They wanted me to be this or that vice-chairman; I said no. Actually I do not want the trouble, because now there are a lot of alumni associations that are quite [unclear], right? I am too lazy for that. But I cannot always refuse this customer; he said, then take some of it on. I said this position is not very lively; whatever I can pick up I will pick up. So I will do one—that is one thing.

**R1 (01:04:15)** — Second, I want to tell you: your wealth, I have nothing that can come to me—conversely, my wealth you do not have. Because I have a great many scenes here; this is my frame. And my frame, as I said, because it is simple, my frame does not need deep digging; my workers cannot even remember it. So it is: as long as you are willing to reduce it, it is all money.

### 9. What survives: lineages, the state, and the Uzbek transfer (01:04:44–01:14:26)

**R3 (01:04:44)** — So the 10% you mentioned just now—that may be the robotics field?

**R1 (01:04:48)** — Yes, this one is the same; we have roughly three major segments.

**R3 (01:04:54)** — Aerospace—I think the profit there is actually very high.

**R2 (01:04:59)** — No, he has to bear some responsibility for the state. Right, right.

**R1 (01:05:01)** — This is—this is actually the idea of enterprise reform. I am not being old-fashioned; the old-fashioned cannot change. I think there really is something like being built to last, and it is not about technology—not about technology.

**R3 (01:05:15)** — Is it national destiny?

**R1 (01:05:22)** — Once you are blended in—once you are blended in, losses. It is like a population, whether a race or—and its real foundation is passing it down from generation to generation. As long as the procedure continues, the enterprise only has to survive. The agreement changes: we have talked for so long, and we as people have already changed several times—I am no longer the person I was just now. Enterprises are the same, but as long as I survive that is enough: find a similar kind of person, similar kinds of things, and keep surviving. I think the root of your enterprise is the model of all things; that is what it is founded on—it is called a procedure.

**R1 (01:06:07)** — For survival—look at Hu Xueyan; there were many like him, right? But in the end he could not do it simply by paying out. Take me: I am a warlord, I come over and just take it. I tell you, I say I will reorganise it, and you must blend in. I believe that if he had kept to grain and made his fortune from that, he would also have been locked in. There must be something that blends into the nation's bloodstream and changes, and that is why [unclear: possibly CITIC] has survived. Of course, whether there is more to be added later—you have to keep reintegrating. Our auto industry actually has this problem: we used to learn from the big ones; now any brand, including SAIC's, is not on the market.

**R2 (01:06:56)** — It does not matter.

**R1 (01:07:00)** — Whatever it is—Tesla, Ferrari, Rolls-Royce, or BYD—it is because you are not in the bloodstream. Of course you see they are also in the future: battery swapping will also have to blend into this, right? It may also be in the national strategy. BYD—you might think China finally arranged a joint venture to go abroad.

**R1 (01:07:36)** — Local—this is the local dish, but it is a [unclear: "sheep seat"] and it can have its subject content, a certain international influence; that is one aspect. Of course there are certainly other strengths. I think in the end you must blend into the bloodstream, into the blood. Aerospace is also the future. Robotics we count as a big one. Compute—why compute is the future we need not say. Why compute plus humanoids: after our victory there will certainly be a great many pumps and valves and connectors in it.

**R3 (01:08:20)** — Right? We outsiders really did not think of that at once.

**R2 (01:08:23)** — We only think of it as a product advantage that plugs in here.

**R1 (01:08:25)** — If you think about it—like the connector when we wash the car, there are connectors; and there must be some inside the washing machine too. And then there is energy.

**R3 (01:08:37)** — Energy—if I may interrupt slightly—in this field you mentioned, which company occupies it at present?

**R1 (01:08:43)** — Many players [unclear]; there should be many.

**R3 (01:08:48)** — But no single one is particularly—

**R1 (01:08:50)** — Right, no single one. That is because now—you think even space has commercial space now. Right, right, that will come. But in this we are completely open on development; at this point I bring in a great deal from being a state enterprise. After all, at China Spring, even if your level is better than mine, suppose [a colleague] did not know it, he would probably come to me first.

**R3 (01:09:15)** — Right? That is, in the whole domestic AI field they will still look for local ones, and they cannot cooperate with foreign ones.

**R1 (01:09:22)** — That depends on the field. For instance this one of mine—of course I should not bring up military industry. I think military industry has the strongest exclusivity, so my brand premium can be cashed there; the others really do not matter, right? So this is still what we think: on energy, as we said earlier, do not see yourself as too small—our child, a broken spring maker. I think energy is the same. Thousands of years ago it was not that I would go specially to that tax man [unclear]. And now look, people have already started on [unclear: possibly "fusion"]. So traditional industries can innovate in the same way. So we say, do not think too much; but traditional industries do have innovative enterprises. Whether you yourself can do it, and how—first set that goal; it is not about collecting [unclear].

**R2 (01:10:31)** — So just now we said one is—we said one is ASO; let us discuss that—and what is the other one?

**R3 (01:10:38)** — Energy. In the energy industry, where are springs used?

**R2 (01:10:42)** — Right, the same.

**R3 (01:10:43)** — That is also energy extraction [unclear].

**R1 (01:10:46)** — Let me tell you. You see the air switch we have now—there is a puff; that is gas. But in real ultra-high voltage they are all springs a metre and a half high. Ultra-high voltage is certainly like this, because it is the breaker. First let us take a mechanical breaker: in the opening and closing process, if the speed is too slow you get [unclear]—very unsafe. So it must, like a hen, be trained first; the uniqueness of the trained thing is that when the speed is extremely fast, it is not easy—

**R2 (01:11:16)** — —to produce this kind of thing. Will there be demand for going abroad?

**R1 (01:11:20)** — Right, that is us—

**R3 (01:11:21)** — This is a very strong one [unclear].

**R1 (01:11:22)** — Right, and we now have it cashed. In the auto field it is technology transfer: helping Uzbekistan—[unclear: an Uzbek company], they are a central enterprise's technology—helping them build spring capability. They are equivalent to what we were doing decades ago with localisation, in Zhu Rongji's localisation era; we find a way to borrow this. That is to say, in this place, in China I may make nothing [unclear], but when I get there I should be one of them, right? I mean, I am not solid, I do not run fast—never mind; as long as I run faster than the others, this boss will not be disappointed.

**R3 (01:12:00)** — Is there anywhere with tigers?

**R1 (01:12:03)** — Or a place with no wife [note: he seems to mean a place with no incumbent competitor], right? Then my monkey can rise up. So this is also our attempt this year. This year our agreement is signed, and next is helping them train; a lot of people will come from our side. Last year we had already recruited people—the materials people—doing internships here, when the project had not been mentioned to me; anyway it could not be set up. Milk as well; we go through their aftermarket too, quietly [unclear]. So we brought it in and did some of it. So you see, this is all human resources work.

**R2 (01:12:43)** — Right. In this kind of process of energy going abroad, if it is a state-owned name, when it comes to springs, will they also mainly prefer China Spring?

**R1 (01:12:53)** — No, because we still have to get in. His design certification threshold is relatively high now. But we—it is like at home: the eldest is often the most capable.

**R2 (01:13:06)** — One is—

**R1 (01:13:08)** — Yes, yes, yes. The eldest naively thinks it is all mine, and what he does not care about gets taken. That is how time is; so there is a great deal. When we want to go back again, he has already occupied it.

**R3 (01:13:26)** — Right. Who are the competitors at present? You were telling them.

**R1 (01:13:29)** — Ours is like this: two or three abroad, two or three domestic. But in the various auto fields, and in different fields, there are also things we simply will not do—others already do them very well. I mean the listed ones: two private companies related to autos are both near Zhuji in Zhejiang, near Shaoxing. In the Shaoxing area, one is [unclear: possibly Huawei], one called [unclear], and one in the north—north north south. They have a thousand and one ties with our Taizhou plant [unclear: possibly "our spring plant"]. Because China Spring—we used to have a deputy plant manager who went back to the OEM; the OEM originally did some of that sort of thing; after he went back to the intermediary, over there they spent. So now, is the spring under—

**R3 (01:14:26)** — Is it Shanghai's advantage? Some of it may have been split off to Zhejiang—a great deal of manufacturing.

### 10. Customers as a portfolio, air suspension, and the aftermarket (01:14:34–01:26:19)

**R1 (01:14:34)** — These two years their growth rate has been fast; even in some fields. For example, we used to be far ahead, and we are still first—they are second, running neck and neck, and their growth rate may even be faster than ours. But on this point I think we are relatively mature. What is our lesson learned? Because in their high-growth period we only—we followed SAIC Volkswagen first, and then it was very sad; we were the only one blooming. In the period when our share of Volkswagen's business was half of it, we were half of it. Right, if we had been making for others then, they might have had a bigger share than us. In this market, [unclear: possibly Huawei] may be following BYD, so their growth these two years has basically been double. So it turns out that these two years we do not plan that way: we do BYD too, we want to expand, but I have set a line—BYD is not allowed to exceed 10% of my total sales.

**R3 (01:15:41)** — Then it may be relatively hard to make money, right?

**R1 (01:15:43)** — Right? For us the profit is relatively good—a thousand people, a thousand faces. For example, he does this piece, and other suppliers have this themselves, so the next supplier is basically pre-fixed by him in advance. But if he does not do this piece, does not master it, or has no bargaining power here, the price will be higher. He does not have our piece. So our competitor—you see—high share, high margin, so these two years they are preparing to list. But what we do now is a portfolio. For example, our pollution-free economy; others—Chery: Chery says the whole Alibaba Cloud capacity is for me; we have six-odd billion there. For example—I say I do not know—you exceed a third of yours, and then my colleagues below ask why sixty or seventy per cent is his when he has not invested a cent, and we still have to treat him like a father.

**R3 (01:16:48)** — Your philosophy is the same as Apple's: no supplier is allowed to be too big; you must cultivate several.

**R1 (01:16:54)** — But equally, the customers who take our capacity cannot be exclusive either.

**R2 (01:16:59)** — Right. So from Huawei—the reason they are like this is to some extent that the threshold for entering other segments is too high, so deep binding is simpler. Jiangsu and [unclear: possibly the Bank of China] signing there—what exactly is the threshold for him to enter the other segments?

**R1 (01:17:21)** — I think it is like this: for cars it is now less and less obvious; it used to feel as though technology was the acknowledged position. Because it is mass batch production, unlike aerospace—aerospace is one in a thousand; that one must have been good before. You cannot say the management changes for a while—especially where safety is involved, he cannot do it that way. So now BYD—why has my volume come up again? BYD now wants quality. This kind of large-volume project is increasing, and we have more of them, and we also have to control. And BYD has its own [unclear], and cash, and finance people, and also its occupation of my funds. If it is too much—because we are originally a first-margin business—once he occupies too much, my cash position also goes, so I use DBRD; I set the position at only 10%. Like Chery or the others, I say: within 30% of your local share. Beyond that, not allowed.

**R2 (01:18:38)** — And if it is still there, we must make something new come out.

**R1 (01:18:41)** — Only then can it be special.

**R3 (01:18:43)** — Sorry—the spring supplier for him, just to confirm.

**R1 (01:18:47)** — For Shanghai's Tesla, before, it was said to be 100%. And their North American high-end models, Model S and Model X, and the German plant, and the stabiliser bar—we also export those. That was at the beginning. Their strategy is also—

**R3 (01:19:09)** — Everyone—

**R1 (01:19:09)** — —can listen. Then they found another two brothers and the like. And one called [unclear: possibly Nobel], also a family business. That one, in terms of current technical strength, I think is the strongest. Then the three of us split it a third each: we have thirty-something, each of them thirty-something, like that.

**R3 (01:19:30)** — But you are also the only one in China.

**R1 (01:19:32)** — Actually, at present. And on the basis—but Tesla is not a very good customer, is it? I evaluate customers as I said up there: on technology, this technical team of theirs—this team is not mature. In management they may be mature, but in technical understanding—

**R2 (01:20:00)** — Up there it is them.

**R1 (01:20:01)** — Basically China, Germany, America—America is certainly very good. China, through this team—he actually uses management methods to solve technical problems. How is that written—

**R2 (01:20:13)** — It is the style of their China boss.

**R1 (01:20:15)** — Right, just like that. For example, this technology has not broken through, which is to say Alibaba must have a general manager, and the general manager must be financially solid, right? You cannot say that everything must be emphasised, and then solve it through emphasis. He does not use management problems to solve technical problems, which shows he himself is going mad. The reason you cannot grasp it must be that you cannot hold it—you have no technology, right?

**R1 (01:20:37)** — That is one. Of course, if he asks—information should be connected; other companies like BMW and Mercedes ask whether I am willing to lend the information, including dates. I say I am willing, go ahead. Then Tesla gave me—they want money too; I said I will not give it. Why? He will only use it as a stick when a problem arises. But you are willing to discover problems with me, solve them, and improve together—then I am willing to give it to you, right? For example, I am writing here, and [a colleague] writes well himself, and he says your pen could go like this, or like that. We can also see—we have that centre; I write the whole process, and it would be best if you were beside me, right? But if instead he is on camera while I am writing, and I take a sip of water in the middle and he immediately reminds me that I cannot drink water—if it is like that, why would I let you be beside me with a camera?

**R3 (01:21:37)** — Are the springs for an electric car exactly the same as for a petrol car? Or will an electric car have something?

**R1 (01:21:41)** — I think exactly the same. Apart from air—[unclear: "the air family"] may see less, but the penetration rate is a problem. Second, air—in the air case it is unsuitable, because let us think from the fundamental principle: how small must the air in a room be compressed to produce an effect? Hydraulics can do one to one: I push one centimetre here and, if it is one to one there, one centimetre moves out there. Air is not like that: I push one centimetre here and there is not the slightest effect there, right? That is one. Second, in air suspension there is bound to be a lot of flexible material, and that flexible material's ageing will be a problem—for example rubber will age, that flexible thing.

**R1 (01:22:36)** — Third, you say leaks. Let us suppose air is easy to find—it is still easy to find, right? One look and I see it at once. With air you do not need any [unclear] to find it—these things cannot be reduced, and moreover the air molecule is small. Theoretically possible.

**R1 (01:22:55)** — Then let us talk about scenes. In winter, if your air comes from outside, it absorbs from outside; in between there will be icing at the connection, and below there will be condensation; all of this will happen. So you must seal it, and once sealed you have the sealing problem. So this technology—and from this example, in every respect the enterprise's response will certainly not exceed AI's.

**R1 (01:23:23)** — What we have in reserve is the electric lift, because we do not want to solve too many problems; we only need to solve lifting. For example, an old person getting in thinks it is too low, so maybe raise it a bit; getting out, too high—[unclear]. For the [unclear] there is also one: of course, lower it a bit. We solve the main pain point; there is no need to want both. Because I think when a thing is not thought through, one should accumulate. But if you really have grasped the pain point, you should be decisive, right? But from meeting demand to actually industrialising it, you should still be decisive, not [unclear]. So ours is electric; ours is one of their concept-test contents.

**R1 (01:24:12)** — Also, we have a Datong pickup at SAIC [unclear]. Before—because especially the US and Southeast Asian pickup markets—what I value is not that I can do aftermarket on their vehicles specifically. What I think is that whether I recruit you or not is actually not important. The whole market is now extremely [unclear], with prices—today 20% off, tomorrow 20% off again, right? Then we go and do aftermarket. Does aftermarket still go through these 4S shops, or does that mean rebuilding the channel? And also the Chinese market: in future aftermarket retrofits will certainly take off.

**R1 (01:24:54)** — Think about it: he wants to raise the ticket price. Before, say it was a volume of ten million, thirty million—that did not matter. Now suppose the volume keeps falling every year, but the ticket price must be raised. I sell you a car, and with this car, besides selling you this car, what else can I sell you? Then he will certainly open it up.

**R1 (01:25:18)** — The priority of the aftermarket [unclear]—apart from the one the girl likes, where we did a little, most of it is still—because we try it online; there are some points, but not yet truly with—equivalent to being on the starting line.

**R2 (01:25:39)** — This is a very valuable thing—a track pre-buried for the future. I am sorry, this may not work domestically, but it can also go abroad. Then where do you find people like this?

**R1 (01:25:55)** — Ours is like this: before, we all relied on our own interest—passively, we felt the same—like value-level analysis, so things worth polishing like this we go and do for the company. So actually, including that in future some places may be decorated into co-creation, it must be healthy.

**R3 (01:26:19)** — Just incubate it internally.

### 11. Incubation, sites, robots that fall over (01:26:22–01:40:05)

**R1 (01:26:22)** — Right—incubate it internally, polish the API a bit, think it through. Do not hand somebody a T [unclear] and have them think it is still nonsense. When I was at university I did it to stick to something, and I made 500 yuan. He asked me to design a mechanism: this mechanism follows the sun, it turns by itself, and then follows the sun for the photovoltaic [panel]. Right, the PV panel I thought was reasonable, because the projected area is different. For example, with the sun like this—

**R2 (01:26:52)** — You are on a slant—does it have a sensor? He, he, he—like that—

**R1 (01:26:55)** — It is equivalent to very low utilisation; it must turn over, and only then—right? But previously it was a water heater, and on the water heater there is one pipe; no matter how the sun shines, its projected area is a rectangle. So after studying it for a long time, I said: your proposition has a problem. You see, the area is the same; in theory there is no need to spend so much effort on it. To design a water-turning mechanism—I said, just leave it in there; with or without, there is not much difference. He said what you say makes sense, and gave me 500 yuan; I said I do not want it. He said you kept us from going off course.

**R2 (01:27:36)** — I guess this is the sort of thing that has to be done, right? Having mechanical thinking but lacking the other—the two kinds of thinking; lacking the mechanical thinking of the one with the control task, but having refined thinking. That makes sense.

**R1 (01:27:50)** — More interesting: the light now is good—each to their own, right? Because it is a plane; its projected area is—so in here we also have corresponding—

**R2 (01:28:03)** — —some of it. But this interest group—from having an initial idea to the end—is actually a very long process. Right, how long does that generally take?

**R1 (01:28:15)** — To run one out? It is like this. Because although we say we go about it by control, we objectively recognise that we are not missiles; our speed is actually slow, very slow. Because of our knowledge structure: you see, most of the people we recruit studied materials, mechanics, and there is a great deal they do not understand.

**R1 (01:28:37)** — Incubating this—my initial idea was, first, to open up wisdom, and second, to solve a kind of fatigue. Every one of our springs is actually different, and once you see the physical object it is not at all what you imagine; they are all bent, or in all kinds of shapes, and locally each one changes too. But in fact once you have done ten projects you get aesthetic fatigue. It looks different; what difference is there in substance?

**R1 (01:29:16)** — Let me give an example. Suppose we are all neighbours: I am flat 101, you are 201, 301, 401, 501, and one is 3404 [unclear]. I find them the same. But then a designer comes, specifically to build wardrobes for us. He goes to 101 first; he is a novice at wardrobes—not that he has not learned a lot—and he finds our needs are all different. But by the time he reaches the twentieth he has already started to feel sick of it, because although there are wall cabinets and all kinds of cabinets, for him they are actually the same. Our engineers have this kind of problem too. What I said just now really means: you play for a bit and hold it for me, right? A bit later, what you want—on the basis of these things, from now on in the work there is at least some relief; he changes his brain.

**R1 (01:30:13)** — But afterwards there is still, after all, the urgency of the enterprise's development. You see it clearly, and you are not able to do it; or some people are not willing to cooperate with us. Because even if the boss agrees, the subordinates do not necessarily agree; the two of us bosses agree, and the subordinates still do not necessarily agree, or there is no time. Then we say, there still has to be time. So our talent structure is also constantly adjusting. For example, do we now involve a lot of software? We now have industrial design—two of them are human-computer interaction, plus one in industrial styling design. So our talent structure has to adjust accordingly.

**R1 (01:31:02)** — Also at this point it is not just a question of money: go and find this information, this cooperation, these suppliers. At that time, for example, we would watch videos to see how this field should be, and we could transplant it over; that is digestion and absorption for our employees. That is relatively [unclear: possibly "paying back"]. And some say, this one does it better, so you just ask like that; after more of that communication, slowly the wisdom unfolds, your network slowly emerges, and later you really go and think about how we should actually do this.

**R1 (01:31:39)** — And then in what they call—for example SAIC's, the pickup I mentioned, SAIC's. After all, we seem to have a Changan Beta as well, and it happens that that person very much agrees with our philosophy, so the two pieces came together. There are also a lot of coincidences; it all looks like effort. Like you—we are both PhDs, both professors, we have seen a lot of records, and actually it shows it is blessing. Only if you did good deeds in a previous life can you—

**R2 (01:32:08)** — —get into university. So this needs some thinking.

**R1 (01:32:10)** — A breakthrough up there. Is your side ready? Ready? Computer and what not—you first. Then we will have a look.

**R3 (01:32:21)** — Is the plant actually in Shanghai? Or is it mainly—[unclear].

**R1 (01:32:25)** — Ours is—Shanghai, Wuhu—

**R3 (01:32:28)** — Chongqing too; there is one in Chongqing as well.

**R1 (01:32:30)** — Right, one in Chongqing, and one in Jiading in Shanghai, which is wire rod—a processing plant that supplies raw material to the spring—and [unclear] with Japan, which is relatively strong in this area. The company in Tianjin is under [unclear]; there is one called Japan [unclear], called Central Hoko [unclear; possibly a spring maker]; there is no Japan Hoko; it is the second. Then the central one has a core enterprise supplying the distributor with stabiliser [bars]. At present it is roughly like this; overseas there are only some chain shops and offices.

**R3 (01:33:12)** — Which plant currently has the most industrial robots? That is, where do you think the smart manufacturing level is highest?

**R1 (01:33:26)** — At present they have AI, and we also have one of those—an art one—inside.

**R3 (01:33:31)** — I saw there is an AI something right next to you.

**R1 (01:33:36)** — Yes, yes. That representative—I have been to see it too. I think for industry it may still be relatively feasible, but adding it to the environment I think is still very hard. For example, something I saw with my own eyes: [unclear: possibly Unitree] over here is really just a display, though he says R&D. And of course he can do tai chi or whatever, and then as we walked over it fell down and lay on the ground twitching like a fit—really, the state was like a charge. If somebody kicks it carelessly, basically it is still not accepted. So his control, really—

**R3 (01:34:37)** — Actually it is still—

**R1 (01:34:38)** — Quite—right. And there is another. Anyway, as you said, over here—for example, at night we order this, suppose a barbecue; a coastal one, the fastest, holds a beer bottle and cracks it for you, brings it himself. We either run, or we think he is stupid, right? But if you keep going he may learn. He may learn; he may take this as corpus and learn by himself. The child bangs his own head, right?

**R1 (01:35:21)** — If two people fight and one hits the other with a beer bottle, the robot will be too. And there is the cognitive boundary. Some people now study cognitive boundaries specifically; if the cognitive boundary is not broken—

**R2 (01:35:33)** — Then someone comes to you for authorisation.

**R1 (01:35:35)** — How do you feel—he asked for leave? Second, for example, when he has fallen, does he choose to struggle up with effort, or does he first lie flat, return to the initial state, and then stand up step by step? Our children have this learning process too. The child is also afraid of falling; at first he freezes for a moment, then his whole body goes stiff, then he does not move, then he starts to cry. From that, slowly rolling on the ground, and then slowly, naturally, like that, finding it again. You would not think this is a student learning; they will be fast. But this point—

**R2 (01:36:16)** — No—why do you—

**R1 (01:36:18)** — —think?

**R2 (01:36:19)** — They will be fast? His choice.

**R1 (01:36:24)** — I—I do not mean domestic; I think foreign ones will be fast, but domestic ones will quickly be banned. Because with some things the idea is harder than the doing. The hardest is thinking of many things—the real breakthrough. Now the hardest is thinking it up; the doing is like ejection—the hardest thing about an electronic battery ejection is thinking of it, not doing it. That is the one just now.

**R2 (01:36:54)** — The example of the robot falling over—it gets up by twitching; it must have some springs on it too, so would slowly getting up with them be a completely different thing?

**R1 (01:37:08)** — But whether there is a spring in this thing—then it may depend on upgrading his mechanism. Once the mechanism is upgraded, there is another mode where the spring can; and another mode where the long square [unclear] does not work, right? Yes—like diabetes, some can follow the swelling and let it become the main force. That is also possible: I prop it up here; it may also be a matter of looking at the mechanical structure.

**R2 (01:37:32)** — So is it—I am rather curious. If it fell on the ground twitching, and we now suppose we solve—

**R1 (01:37:39)** — —this problem—

**R2 (01:37:40)** — —and suddenly find that solving this problem is, on one hand, a question of the cognitive boundary. But beyond cognition and solving it, there is also a physical problem that has to be redone to let it slowly. At that point you find that, for example, a spring like the one I made before is not suitable. Right, I need to make a new spring. And conversely, if that spring of mine has not been made, then although my cognition has caught up, in practice the problem still cannot be solved.

**R1 (01:38:06)** — I think—I think the two examples I just gave: first, does the enterprise structure need adjusting? That may need re-evaluation; some may need no adjustment and it is gone. The team's cognitive boundary—this cognitive piece may take a process. For example, did my [unclear: possibly the quadruped] fall in a slippery place, or where the main force is big enough; on a flat surface, or on a slope? That is what he has to solve at the control level, in his control strategy. But the mechanics above may not be right—and it is right.

**R2 (01:38:42)** — So what I am rather curious about is: in this process, where does the robot's neck get stuck—the robot's—because it has produced a lot of functions. And like just now: we humans have five fingers and play the piano; I could absolutely make a robot with six fingers. Then what it plays is different from five fingers. But because there is one more finger, to some extent I may not need to push certain functions to the extreme. Because I have one more—this is the cognitive boundary. Once I break through it, then mechanically I can jog along in small steps. But if the cognitive boundary has not been broken, then to some extent the demand on mechanics is actually higher.

**R2 (01:39:26)** — That is my guess. So from the computer understanding just now, it means: suppose this morning I study a person—because the child crying there is equivalent to the whole system rebooting, which is a period of time. If I take that route, then most likely my demand on mechanics will be higher. If I do not take that route, then I think: fine, actually I can quickly [unclear] with Jet Li, right?

**R2 (01:40:05)** — Bang bang bang bang.

### 12. Knees, six fingers, and the Xinyu plan (01:40:07–01:57:28)

**R1 (01:40:07)** — Then look for one—possible. But there is also the intelligent robot, the human robot; you are with this. This one also has something: how it actually came about I do not know. But I vaguely feel that some people, experts in various fields, once they reach a certain mechanism, will they not have the same common primitive impulse as ours? Because, as the ancients said—and I think it is good: why do we learn? To establish a heart for heaven and earth, to establish a life for the people, to continue the lost learning of the sages, to open peace for ten thousand generations. Although Westerners—including Jack Ma—may not have this line, they may have the same impulse.

**R1 (01:41:02)** — For example, I am an expert in bones and muscles, or in biology, or in some medical field. And because my knee is bad—I used to play a lot of ball sports, tennis, basketball—my ankle went often. But I found that some people with good strength have nothing wrong with their ankle structure. So you rarely hear someone say—I suspect their structure was good to begin with, and only the muscle strength was insufficient, so they need to do ankle work or some functional jump; if you want to do sport you must [unclear], even do some specific training. But a great many of them may just be habit. This is the structure itself—the bone here—rather similar, but inside there is the tendon and the muscle wrapping. Its wrapping is sufficient; it is equivalent to—if you do not take [unclear], the mechanism there cannot bring it over. But inside here, if you do not take a breath, it is still relatively simple.

**R1 (01:42:13)** — This one is like this: it can do this—the area there is constrained, and it helps constrain it, so most likely it will only rotate like this; it is in a confined space. Actually if your elasticity is slightly worse, then this begins. Studying this person, he said: if I were [a colleague] and had to hire one more, I would certainly design the knee structure a bit better. Equally, why must we go for—what, a human robot? Me too. You just said six digits; I can have eight digits and eight analyses, right? Or I simply have a phone at each place, or two tables, and my hand speed is fast enough—with two hands fast, one finger is enough; a bit faster and I take it at the same time; at the same time I may need that horizontal kind.

**R1 (01:43:17)** — So why must there be human-likeness? I think it may involve a milestone: once I reach this—and including our AI now, if AI can reach it, then it overtakes in seconds. Your human IQ is two or three hundred, 200, right? That is 200, right?

**R3 (01:43:45)** — Otherwise, now it should be said that it has already reached around 140.

**R1 (01:43:48)** — Right, the latest AI—his twenty or thirty thousand may not be clear, right? Once it reaches this level, then immediately. So we actually have to seize this time; a great many people will want to predict this time; there may be nothing to predict. And I think this stage—

**R3 (01:44:07)** — —actually the GPT moment has arrived.

**R1 (01:44:12)** — All of those will happen. So I also have not figured out why they want to make a human robot, right? It is to find that kind of friendliness. Our friendliness—a dog is quite good too. Right, right.

**R3 (01:44:25)** — It is that most physical designs are designed for people; otherwise, for example, some visual ranges might not apply. There is a bit of that argument.

**R1 (01:44:35)** — So I switched very early—like with foreign [products]; I think these things are really very promising. Because I myself—like my deliveries, you might think [a colleague] has it easy, but if I drink too much or am bedridden, who does it? Because at the time I always felt this was meaningful and valuable, including clinical care and so on.

**R1 (01:45:09)** — And later they said you also have to consider emotion, and that is one. What are they doing? You see, Musk has a high IQ; I want to buy him too—my low IQ is better than buying a high IQ. And some people—what exactly is their original intention and motive in this field? I am watching them now; you are thinking it too, I am not deceiving you; I just look. Now it is about having marketing gimmicks today.

**R1 (01:45:42)** — And we want to put the mechanical arm on our industrial robots, the equipment for a long time, so that our awakening, and including a reasonable one. Like that human robot, the giant robot—you know perfectly well that its work will fall over; fine, then swap it. I will simply make a mobile platform underneath, call that AGV below, would that not do? Then above I just use his two hands connected. I am now on this.

**R1 (01:46:23)** — For a general investment model it is actually perception plus this degree. We say this thing aloud: perception is here. In this sentence we say—this is generalisable; this is my greatest ambition. That is, if you make this thing and China Spring cannot make it, it does not matter; inside the car, outside the car, it does not matter to me. As long as you need this kind of technology, whatever industry you are in, I do not care; you could be stir-frying. Why do I now distinguish inside the car from outside the car? Because I am now speaking with my backside sitting in the car, so I have to distinguish; but once it is open to me, it is all open space.

**R3 (01:47:19)** — So it becomes a raw material supplier to the machinery industry. That is what it means.

**R2 (01:47:27)** — Standard parts machinery.

**R1 (01:47:29)** — A supplier of all standard parts, including service quality. I think you can also export management. For example, we say AI—is anyone interested?

**R1 (01:47:43)** — Besides helping us learn this, we have set up something called the Xinyu plan—"heart-language," the state of the heart, the mood. Because our volume is not large, our Xinyu is about two to three years. Why Xinyu? The character for "to learn" is two wings above and one below [note: he is taking the character apart]. This one is: you do it three more times a day. But this plan—being born is only 10%; the rest is actual practice, or it is just face-slapping. So without a bit of theory it will not do; you have to learn. The traditional character for "to learn" is two hands with something in the middle. That something is the scientific principle; you have to keep using your hands inside a house, with small words and words, right?

**R1 (01:48:26)** — Teacher and student—we may also have a flipped classroom, and then project-based teaching similar to it: we sort out the profit over here, and practise over there; we do this kind of thing. The courses we mentioned—I build the foundation. Because I used to be in that rectification [unclear]; I felt the courses the people on top talked about were not listened to, and everyone below was asleep. If they understood they did not want to listen; if they did not understand they did not want to listen either. Taught too practically, it is no good at all.

**R1 (01:49:02)** — For example, teaching—say, the application process for a purchase order. Is that not what everyone does? You go there and actually purchase, and you learn. Right—there has never been a person who, before buying a house, first signs up for a training course to learn the procedure for buying a house.

**R1 (01:49:23)** — Actually these—I think this is the meaning. So that is what we said about the way of the people who do it; I think this case is mainly called: loving a line and doing it is not as good as doing a line and loving it. Because to do a line you must look at your own talent. For example, I suddenly think of taking up gymnastics, because you look at my talent—this thing is related to talent. Or for example I suddenly want to do mathematics—then you also have to look.

**R1 (01:50:01)** — But most of what we do is not the same as talent. To bring the team up, you have to keep raising the demands on yourself. Or your cognition—of course, then you will do it with yourself. If it is like that.

**R1 (01:50:28)** — New thinking, new scale—with these things we can then talk about intelligence.

**R1 (01:50:50)** — Plus some—it is equivalent to this land being strict and formidable; we have to plant a seed, so to speak.

**R2 (01:50:58)** — It is equivalent to a version of a 985 undergraduate course coming out. I think this undergraduate course—

**R1 (01:51:05)** — And then I did it. And if you still do not believe it—then I have found that when you have no aptitude, I find a way to inspire again. If there is really no aptitude, then I find a place where he can participate. That is, if you still have no willingness, then how do we go? So this is also a joke; we want to build our—actually, in looking after him well, we must not waste his youth and his feeling. If he is not good, you think of giving him more. But when we reach this thing we support him in time; only then do I think he can develop sustainably.

**R1 (01:51:50)** — I am not doing this as charity, right? I must consider the majority of the team, but I also must have this social responsibility; so this is ours, roughly like this. So on the basis of this Xinyu plan, what we think about is these courses. And then look—we actually do not need to train their skills; we should just stand together and open up the imagination a bit, and that is enough. So with my colleagues, this is what we stopped at.

**R1 (01:52:30)** — The production situation—this is one. Second, that I can.

**R1 (01:52:41)** — Now, finally—for example, like a waterfall; doing it that way, we have actually also made a revision, our proof or—below, as long as there is a basic actuator, ask: for example this is a motor switch, there is a hydraulic cylinder, there is a hydraulic pump. As for how you want to run it, or through the working engine—

**R1 (01:53:27)** — We are also going to do some data operations. More important is still to scan the market, scan the technology, scan those below—which actually means finding some people you trust, and he is—people, and what not. Once these are done, at that point, based on what situation, taking on work responsibility—that is one possibility; there will also have to be a supply chain, the car shop, and what else; all of them may be needed, but the combination will be different. Then I think the [unclear: "Korean War"]—that is another way of playing. The data below basically still supports it; mainly it relies on this.

**R2 (01:54:11)** — Relies on—yes. There is research now.

**R1 (01:54:18)** — Right, the pressure is relatively high.

**R2 (01:54:19)** — Right, and the volume is relatively large. Below, there is relatively more use of something like a control space as the middle platform.

**R1 (01:54:26)** — And we now—we now—

**R1 (01:54:34)** — Above is one; the way below is that it is itself—for example, as you have seen in a factory: there is a pile of parts boxes. Before, a worker had to pick: for this model I take these parts, then a few of those, and then a small tag is matched, and behind it are lights of this kind. Once you have filled a tray it is more complete. Then you take a new tray, and it shows a few on it, and you grab according to that quantity; once filled you switch the light off, and once all the lights are out you take it down. Even at the grassroots level it can be data operations, done like that. So that is what we call it.

**R1 (01:55:18)** — Below is a matrix, including data, which is also a matrix—only it is a matrix of [unclear: possibly "embodiment"], and it is put inside: internal resources, external resources, including core strategic suppliers, my school resources, what performance, and some on-post. So now it may also need—I should now do a value maturity analysis: which things in this field I may need to involve, and look for a new external resource to cooperate with. Then external resources and internal resources are also—no; bought today, or asked for by myself tomorrow; today I only remember what I will need tomorrow, possibly. Then we have this kind of organisation structure of [unclear: "all staff place"].

**R2 (01:56:01)** — In it there is a manufacturing part, possibly a considerable one in the middle. And the middle is driven by this intelligence.

**R1 (01:56:11)** — That is the way.

**R2 (01:56:12)** — But this still lacks such a thing; we can research it.

**R1 (01:56:16)** — We will make one.

**R2 (01:56:17)** — A case, to share this.

**R1 (01:56:24)** — Your robots—you may have half, but I have several hundred, right? And never mind the organisation chart; your organisation chart is still the board. The problem below me is only that it iterates a few layers, right? For me, my nanny is also your nanny; you have a nanny and I have a nanny, only in my iterated layers of data—right, but the basic model is exactly the same, right? You—for example, if you run a restaurant, you have the oil-smoke problem and I have it too, right? They have safety problems and I have them too; I have all these problems. And so on. What is the scene? The scene is that we are rich, and all of it is at floor level.

**R2 (01:57:10)** — Right. This is actually especially interesting.

**R1 (01:57:12)** — Especially suitable for combining theory with practice—traditional manufacturing.

**R3 (01:57:17)** — Its transformation, and industrial robots—these are directions [a colleague] is especially interested in.

**R2 (01:57:22)** — Yes—why can it be upgraded? And I think there is also something in here that is not a fun thing.

**R1 (01:57:28)** — So if you want to learn, then we will go over here.

*[Recording ends.]*

## Notes for analysis

- **Compensation is the interview's central explanatory device**, and R1 uses it at four different scales: the body (a bad knee, a bad ankle), the firm's information systems ("our information system is above our industry—because I need compensation"), the technology choice (new energy as a compensatory bet on a weak powertrain), and the market (springs as the compensatory part inside an electric tailgate that saves motor power). Worth coding as one construct with a stated level each time, since he insists compensation must stay "of the same type" (51:47–53:13).
- **"Inappropriate technology" ("untimely technology") is defined twice**, once by R2 as a neutral-technology problem (02:55) and once by R1 as a problem of original intention and standpoint—the frog in the well, or the engineer who stands inside the robot instead of inside the era (35:53). The two definitions are compatible but not identical; the second puts the failure in the observer, not the artefact.
- **Control theory supplies the tempo of the whole account**: fire, observe, correct, re-aim (17:00–18:07). Note the explicit disavowal of the perfect formula and the confession of slowness ("we are not missiles; our speed is very slow", 01:28:15) — the same metaphor used to describe an engineering ideal and to excuse an organisational one.
- **The handover passage (28:04–29:15) is the only place where the firm's knowledge problem is stated as a task**: what is transferred is the documented project, what is missing is the predecessor's judgement. R2 names it "tacit knowledge" and R1 does not take the term up; he keeps talking about the corpus and the agent.
- **On leaving the car (42:47)** he gives a measurable definition of a strategic shift—more than 10% of profit from outside cars—and pairs it with a name argument (43:27) that mirrors INT-04's opening: the word "China" is a claim that has to be earned by going abroad.
- **Two passages are unrecoverable in substance** and are marked as such rather than paraphrased: the sequence on the metaverse and the "corpus" (29:23–29:58), and the garbled genealogy of the family firm at 11:26. The long passage on the Xinyu plan (01:47:43–01:52:30) is recoverable in outline but the character-etymology arguments depend on the written characters and cannot be rendered in translation.
