# Supporting Appendix — Field Interviews at China Spring

**Companion to:** *WorkLedger: An Auditable Instrument for Measuring Work Output in AI-Augmented Organizations*
**Submitted to:** *Organization Science*, Special Issue on AI-Enabled Frontiers in Organizational Science (Stage 1 proposal)
**Fieldwork:** 29 April 2026, Shanghai
**Interviews:** four (INT-01 to INT-04), 197 minutes of recorded talk
**English text:** approx. 31,900 words

## 1. Why this appendix exists

The proposal argues that work in AI-augmented organizations can be measured without collapsing what was claimed,
what happened, and what it was worth into a single rating. That argument is not only conceptual: it comes from
fieldwork in a firm that is doing exactly this collapsing, and knows it.

China Spring is a 1937-founded manufacturer of springs and stabiliser bars for automotive and industrial customers.
It is a useful site for three reasons. Its work is traceable—orders, drawings, tooling, process parameters, and
delivery dates all leave records—so a ledger has something to stand on. Its performance regime is still
period-based, so the gap between episode-level evidence and annual judgment is visible in daily argument. And its
leadership is actively rebuilding the firm around automation, data, and AI, which means the interviews contain the
firm's own account of what becomes measurable and what disappears when work is reorganised.

These transcripts are offered as evidence, not as findings. They are the empirical ground the proposal stands on.

## 2. What was collected

| Code | Length | Main themes | English words |
|---|---|---|---|
| INT-01 | 117 min | Control theory and incremental correction; inappropriate technology; firm history from 1937; adopting AI and the handover problem; compensation as capability purchase; diversification beyond automotive | 19,000 |
| INT-02 | 60 min | Shop-floor screens and KPI logic; retrofit economics; equipment built in-house; token economics; process atomisation; the enabling organisation | 9,750 |
| INT-03 | 10 min | Generations of managers; mistaking the platform for one's own capability; German service as systemic rather than personal | 1,750 |
| INT-04 | 7 min | What the company name obliges; the loss-making years; shutting one company; sixty-eight days of lockdown | 1,350 |

INT-01 and INT-02 are long, multi-topic conversations that move between the office and the production floor.
INT-03 and INT-04 are short exchanges recorded the same day, and are included because they contain the corpus's
clearest statements of the attribution problem.

## 3. How the record was produced

The source is an automatic Mandarin transcript. Automatic transcription of this material is imperfect: it
mishears technical terms, drops subjects, and on occasion produces strings that carry no recoverable meaning.

The English text is therefore an **edited translation**, not a verbatim one. Filler and false starts were removed;
fragmentary turns by the same speaker were merged, keeping the timestamp of the first fragment; obvious subjects
were restored. What was not done: no passage was summarised in place of translating it, no speaker was merged with
another, no content was added, and no contradiction was smoothed over.

Two conventions mark the limits of the record:

- `[unclear]` — the meaning could not be recovered from the audio or the text. A short guess may follow a colon,
  e.g. `[unclear: possibly the quadruped]`.
- `[note: …]` — an editorial reconstruction of an implied referent, marked so that a reader can discount it.

Timestamps are those of the original recording and are the unit of citation. Where the diarisation split a
sentence across two labels, the fragments were rejoined and the fact is stated in the relevant file header.

## 4. Anonymisation

The company appears as **China Spring**. Individuals appear as **R1** (chairman and general manager), **R2**
(interviewer), **R3** (a second participant), and, in INT-02, **R4** (a further participant present in the room)
and **R5** (voice-over from a company video played during the plant visit). Surnames and honorifics were removed.
Customer names were removed where they appeared; site and account codes spoken as numbers were kept.

Public firms, products, and public figures named in the conversation (Volkswagen, GM, SAIC, Bosch, FANUC,
Yaskawa, DeepSeek, Qwen, CATIA, and so on) were kept, because they are part of the argument being made rather
than identifying information about the firm's people.

## 5. How to cite

In the manuscript:

```
(R1, INT-01, 00:41:12)
(INT-02, §18)
```

At section level the index in `99_index.md` gives the range for each thematic block, which is the safer unit when
a passage depends on the room rather than the words.

## 6. What this corpus can and cannot support

**It can support** claims about how managers reason about measurement, attribution, and automation; about what the
firm records and what it does not; and about the vocabulary in which performance is argued. Several passages are
usable as illustrations of the proposal's central distinction between claim, fact, and evaluation.

**It cannot support** claims about prevalence, causal effects, or typicality. This is one firm, four conversations,
and a convenience sample of speakers. INT-01 and INT-02 also contain long stretches recorded during a plant walk,
where demonstratives ("this one", "over there") point at objects the transcript cannot see; those turns are marked
and should not be quoted out of context.

The transcripts were not collected for the purpose of evaluating any individual, and nothing in them should be
read as a judgment about a named person's performance.

## 7. Files

```
00_README.md            this file
01_interview_INT-01.md  117 minutes, 12 sections
02_interview_INT-02.md  60 minutes, 19 sections
03_interview_INT-03.md  10 minutes, 4 sections
04_interview_INT-04.md  7 minutes, 5 sections
99_index.md             thematic index with locators
```
